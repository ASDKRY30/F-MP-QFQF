const { EmbedBuilder } = require('discord.js');
const logger = require('../utils/logger.js');

module.exports = {
    name: 'guildMemberAdd',
    async execute(member) {
        const guild = member.guild;
        
        // Anti-raid system
        try {
            const antiRaidCommand = require('../commands/antiraid.js');
            const isRaid = antiRaidCommand.updateRecentJoins(guild.id, member.id);
            
            if (isRaid) {
                logger.warn(`Potential raid detected in ${guild.name} - kicking ${member.user.tag}`);
                
                try {
                    await member.kick('Anti-raid: Demasiadas uniones rápidas');
                    
                    // Send alert to system channel or first text channel
                    const alertChannel = guild.systemChannel || guild.channels.cache.find(ch => ch.type === 0);
                    if (alertChannel) {
                        const alertEmbed = new EmbedBuilder()
                            .setColor(0xf04747)
                            .setTitle('🚨 ALERTA ANTI-RAID')
                            .setDescription(`**${member.user.tag}** fue expulsado por activar el sistema anti-raid.`)
                            .addFields(
                                { name: '👤 Usuario', value: `${member.user.tag} (${member.id})`, inline: true },
                                { name: '⚠️ Razón', value: 'Demasiadas uniones rápidas detectadas', inline: true }
                            )
                            .setTimestamp();
                        
                        await alertChannel.send({ embeds: [alertEmbed] });
                    }
                    
                    return; // Don't send welcome message for kicked users
                } catch (error) {
                    logger.error(`Failed to kick ${member.user.tag} during raid:`, error);
                }
            }
        } catch (error) {
            logger.error('Error in anti-raid system:', error);
        }
        
        // Welcome system
        try {
            const welcomeCommand = require('../commands/welcome.js');
            const welcomeConfig = welcomeCommand.getConfig(guild.id);
            
            if (welcomeConfig && welcomeConfig.enabled) {
                const channel = guild.channels.cache.get(welcomeConfig.channelId);
                if (channel) {
                    await welcomeCommand.sendWelcomeMessage(guild, member, channel, welcomeConfig.message);
                }
            }
        } catch (error) {
            logger.error('Error sending welcome message:', error);
        }
    },
};