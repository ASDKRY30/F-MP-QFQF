const { ActivityType } = require('discord.js');
const logger = require('../utils/logger.js');

module.exports = {
    name: 'ready',
    once: true,
    execute(client) {
        logger.info(`Ready! Logged in as ${client.user.tag}`);
        logger.info(`Bot is in ${client.guilds.cache.size} server(s)`);
        
        // Set bot presence/status
        client.user.setPresence({
            activities: [{
                name: 'Developed by: Kry',
                type: ActivityType.Watching
            }],
            status: 'online'
        });

        // Log some basic stats
        const totalUsers = client.guilds.cache.reduce((acc, guild) => acc + guild.memberCount, 0);
        logger.info(`Serving ${totalUsers} users across ${client.guilds.cache.size} servers`);
        
        // Set up periodic presence updates (optional)
        setInterval(() => {
            const activities = [
                { name: 'Developed by: Kry', type: ActivityType.Watching },
                { name: `${client.guilds.cache.size} servers | By: Kry`, type: ActivityType.Watching },
                { name: 'CEO Commands | By: Kry', type: ActivityType.Playing }
            ];
            
            const activity = activities[Math.floor(Math.random() * activities.length)];
            client.user.setActivity(activity.name, { type: activity.type });
        }, 30 * 60 * 1000); // Change every 30 minutes
    },
};
