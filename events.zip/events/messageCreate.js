const config = require('../config.js');
const logger = require('../utils/logger.js');

module.exports = {
    name: 'messageCreate',
    async execute(message) {
        // Ignore messages from bots
        if (message.author.bot) return;

        // Basic prefix command support (for emergency/fallback commands)
        if (!message.content.startsWith(config.prefix)) return;

        const args = message.content.slice(config.prefix.length).trim().split(/ +/);
        const commandName = args.shift().toLowerCase();

        // Simple ping command as fallback
        if (commandName === 'ping') {
            try {
                const sent = await message.reply('Pinging...');
                const latency = sent.createdTimestamp - message.createdTimestamp;
                const apiLatency = Math.round(message.client.ws.ping);
                
                await sent.edit(
                    `🏓 Pong!\n` +
                    `**Roundtrip Latency:** ${latency}ms\n` +
                    `**WebSocket Heartbeat:** ${apiLatency}ms`
                );
                
                logger.info(`${message.author.tag} used prefix ping command in ${message.guild?.name || 'DM'}`);
            } catch (error) {
                logger.error('Error in prefix ping command:', error);
            }
        }

        // CEO Help command
        if (commandName === 'helpk') {
            const { isCEO } = require('../utils/ceo-check.js');
            const { EmbedBuilder } = require('discord.js');
            
            if (!isCEO(message.member, message.author)) {
                return message.reply('❌ Este comando solo puede ser usado por el CEO.');
            }
            
            try {
                const embed = new EmbedBuilder()
                    .setColor(0x7289da)
                    .setTitle('👑 Comandos CEO - Panel de Control')
                    .setDescription('**Panel exclusivo para el CEO del servidor**')
                    .addFields(
                        { 
                            name: '🛡️ Moderación Avanzada', 
                            value: '`/kick` `/ban` `/mute` `/unmute` `/clear`\n`/antiraid` - Sistema anti-raid\n`/role` - Gestión de roles', 
                            inline: false 
                        },
                        { 
                            name: '🎫 Sistema de Tickets', 
                            value: '`/ticket setup` - Configurar sistema\n`/ticket panel` - Crear panel\n`/ticket close/add/remove` - Gestión', 
                            inline: false 
                        },
                        { 
                            name: '🎉 Sorteos Avanzados', 
                            value: '`/giveaway-pro create` - Crear sorteo\n`/giveaway-pro reroll` - Hacer reroll\n`/giveaway-pro end` - Terminar sorteo\n`/giveaway-pro list` - Ver activos\n`/giveaway-pro edit` - Editar sorteo', 
                            inline: false 
                        },
                        { 
                            name: '👋 Configuración', 
                            value: '`/welcome set/disable/test` - Mensajes de bienvenida\n`/embed` - Crear embeds personalizados\n`/say` - Hacer hablar al bot', 
                            inline: false 
                        },
                        { 
                            name: '📊 Utilidades', 
                            value: '`/serverinfo` `/userinfo` `/avatar` `/weather`\n`/poll` - Encuestas interactivas\n`/8ball` `/coinflip` `/dice` - Juegos', 
                            inline: false 
                        }
                    )
                    .setFooter({ text: 'Developed by: Kry • Solo acceso CEO' })
                    .setTimestamp();

                await message.reply({ embeds: [embed] });
                
                logger.info(`${message.author.tag} used CEO helpk command in ${message.guild?.name || 'DM'}`);
            } catch (error) {
                logger.error('Error in CEO help command:', error);
            }
        }

        // Help command to remind users about slash commands
        if (commandName === 'help') {
            try {
                await message.reply(
                    '👋 **Hello!** I primarily use slash commands now.\n\n' +
                    '**Available commands:**\n' +
                    '• `/ping` - Check bot latency\n' +
                    '• `/serverinfo` - View server information\n' +
                    '• `/userinfo` - View user information\n' +
                    '• `/help` - Complete command list\n\n' +
                    '**Note:** Most advanced commands require CEO permissions.\n' +
                    '**Tip:** Type `/` in the chat to see all available slash commands!'
                );
                
                logger.info(`${message.author.tag} used prefix help command in ${message.guild?.name || 'DM'}`);
            } catch (error) {
                logger.error('Error in prefix help command:', error);
            }
        }
    },
};
