const logger = require('../utils/logger.js');
const performanceMonitor = require('../utils/performance-monitor.js');
const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'interactionCreate',
    async execute(interaction) {
        // Handle slash commands
        if (interaction.isChatInputCommand()) {
            const command = interaction.client.commands.get(interaction.commandName);

            if (!command) {
                logger.warn(`No command matching ${interaction.commandName} was found.`);
                try {
                    await interaction.reply({
                        content: '❌ Comando no encontrado. Usa `/help` para ver comandos disponibles.',
                        ephemeral: true
                    });
                } catch (err) {
                    logger.error('Error replying to unknown command:', err);
                }
                return;
            }

            try {
                logger.info(`${interaction.user.tag} used command: ${interaction.commandName} in ${interaction.guild?.name || 'DM'}`);
                
                // Start performance monitoring
                const monitor = performanceMonitor.startCommand(interaction.commandName, interaction.user.id);
                
                // Add timeout to prevent hanging interactions
                const timeout = setTimeout(() => {
                    logger.warn(`Command ${interaction.commandName} is taking too long to respond`);
                }, 2900); // Discord has 3 second limit
                
                await command.execute(interaction);
                clearTimeout(timeout);
                
                // End performance monitoring (success)
                monitor.end(true);
                
            } catch (error) {
                logger.error(`Error executing command ${interaction.commandName}:`, error);
                
                // End performance monitoring (error) - use existing monitor if available
                if (typeof monitor !== 'undefined') {
                    monitor.end(false, error);
                }
                
                const errorEmbed = new EmbedBuilder()
                    .setTitle('❌ Error en el Comando')
                    .setDescription('Hubo un error al ejecutar este comando. El equipo técnico ha sido notificado.')
                    .addFields([
                        { name: '🔧 Comando', value: interaction.commandName, inline: true },
                        { name: '⏰ Hora', value: new Date().toLocaleString('es-ES'), inline: true },
                        { name: '🆔 Error ID', value: `ERR_${Date.now().toString(36)}`, inline: true }
                    ])
                    .setColor(0xFF0000)
                    .setFooter({ text: 'Developed by: Kry - Sistema de Errores' })
                    .setTimestamp();
                
                try {
                    if (interaction.replied || interaction.deferred) {
                        await interaction.followUp({ 
                            embeds: [errorEmbed], 
                            ephemeral: true 
                        });
                    } else {
                        await interaction.reply({ 
                            embeds: [errorEmbed], 
                            ephemeral: true 
                        });
                    }
                } catch (err) {
                    logger.error('Error sending error message:', err);
                }
            }
        } else if (interaction.isStringSelectMenu()) {
            // Handle select menu interactions
            if (interaction.customId === 'ticket_create') {
                try {
                    const ticketCommand = require('../commands/ticket.js');
                    await ticketCommand.handleTicketCreation(interaction);
                } catch (error) {
                    logger.error('Error handling ticket creation:', error);
                    try {
                        await interaction.reply({
                            content: '❌ Error al crear el ticket. Inténtalo de nuevo.',
                            ephemeral: true
                        });
                    } catch (err) {
                        logger.error('Error replying to ticket creation error:', err);
                    }
                }
            }
        } else if (interaction.isButton()) {
            // Handle button interactions
            logger.info(`Button interaction: ${interaction.customId} by ${interaction.user.tag}`);
            
            if (interaction.customId === 'close_ticket' || interaction.customId === 'confirm_close') {
                try {
                    await this.handleTicketClose(interaction);
                } catch (error) {
                    logger.error('Error handling ticket close:', error);
                }
            } else {
                try {
                    await interaction.deferReply({ ephemeral: true });
                    await interaction.followUp({
                        content: '⚠️ Esta funcionalidad está en desarrollo.',
                        ephemeral: true
                    });
                } catch (error) {
                    logger.error('Error handling button interaction:', error);
                }
            }
        }
        
        // Log all interaction types for debugging
        if (!interaction.isChatInputCommand() && !interaction.isStringSelectMenu() && !interaction.isButton()) {
            logger.info(`Unhandled interaction type: ${interaction.type} from ${interaction.user.tag}`);
        }
    },

    async handleTicketClose(interaction) {
        const channelName = interaction.channel.name;
        
        if (!channelName.startsWith('ticket-')) {
            return await interaction.reply({
                content: '❌ Este comando solo puede usarse en canales de tickets.',
                ephemeral: true
            });
        }

        if (interaction.customId === 'confirm_close') {
            try {
                const embed = new EmbedBuilder()
                    .setTitle('🔒 Ticket Cerrado')
                    .setDescription('Este ticket ha sido cerrado exitosamente.')
                    .setColor(0xFF0000)
                    .setFooter({ text: 'Developed by: Kry' })
                    .setTimestamp();

                await interaction.reply({ embeds: [embed] });
                
                setTimeout(async () => {
                    await interaction.channel.delete();
                }, 5000);
                
            } catch (error) {
                await interaction.reply({
                    content: '❌ Error al cerrar el ticket.',
                    ephemeral: true
                });
            }
        } else if (interaction.customId === 'close_ticket') {
            const embed = new EmbedBuilder()
                .setTitle('🔒 Cerrando Ticket')
                .setDescription('¿Estás seguro de que quieres cerrar este ticket?')
                .setColor(0xFFFF00)
                .setFooter({ text: 'Developed by: Kry - Cierre de Tickets' });

            const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
            const buttons = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('confirm_close')
                        .setLabel('✅ Confirmar Cierre')
                        .setStyle(ButtonStyle.Danger),
                    new ButtonBuilder()
                        .setCustomId('cancel_close')
                        .setLabel('❌ Cancelar')
                        .setStyle(ButtonStyle.Secondary)
                );

            await interaction.reply({ 
                embeds: [embed], 
                components: [buttons],
                ephemeral: true
            });
        } else {
            await interaction.reply({
                content: '✅ Cierre cancelado.',
                ephemeral: true
            });
        }
    }
};
