const { PermissionFlagsBits } = require('discord.js');

/**
 * Check if a member has a specific permission
 * @param {GuildMember} member - The member to check
 * @param {BigInt} permission - The permission to check for
 * @returns {boolean} - Whether the member has the permission
 */
function hasPermission(member, permission) {
    if (!member) return false;
    return member.permissions.has(permission);
}

/**
 * Check if a member has administrator permissions
 * @param {GuildMember} member - The member to check
 * @returns {boolean} - Whether the member is an administrator
 */
function isAdmin(member) {
    return hasPermission(member, PermissionFlagsBits.Administrator);
}

/**
 * Check if a member has moderation permissions
 * @param {GuildMember} member - The member to check
 * @returns {boolean} - Whether the member has moderation permissions
 */
function isModerator(member) {
    return hasPermission(member, PermissionFlagsBits.KickMembers) ||
           hasPermission(member, PermissionFlagsBits.BanMembers) ||
           hasPermission(member, PermissionFlagsBits.ManageMessages) ||
           isAdmin(member);
}

/**
 * Check if executor has a higher role than target
 * @param {GuildMember} executor - The member executing the action
 * @param {GuildMember} target - The target member
 * @returns {boolean} - Whether executor can moderate target
 */
function isHigherRole(executor, target) {
    if (!executor || !target) return false;
    
    // Owner can moderate anyone
    if (executor.id === executor.guild.ownerId) return true;
    
    // Can't moderate the owner
    if (target.id === target.guild.ownerId) return false;
    
    // Compare highest role positions
    return executor.roles.highest.position > target.roles.highest.position;
}

/**
 * Check if a member can be moderated by another member
 * @param {GuildMember} executor - The member executing the action
 * @param {GuildMember} target - The target member
 * @returns {boolean} - Whether the target can be moderated
 */
function canModerate(executor, target) {
    if (!executor || !target) return false;
    
    // Can't moderate yourself
    if (executor.id === target.id) return false;
    
    // Must have higher role
    if (!isHigherRole(executor, target)) return false;
    
    return true;
}

/**
 * Get permission level of a member
 * @param {GuildMember} member - The member to check
 * @returns {string} - Permission level (owner, admin, mod, member)
 */
function getPermissionLevel(member) {
    if (!member) return 'none';
    
    if (member.id === member.guild.ownerId) return 'owner';
    if (isAdmin(member)) return 'admin';
    if (isModerator(member)) return 'moderator';
    return 'member';
}

module.exports = {
    hasPermission,
    isAdmin,
    isModerator,
    isHigherRole,
    canModerate,
    getPermissionLevel
};
