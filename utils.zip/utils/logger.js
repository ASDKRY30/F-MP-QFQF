const config = require('../config.js');

// Color codes for console output
const colors = {
    reset: '\x1b[0m',
    bright: '\x1b[1m',
    dim: '\x1b[2m',
    red: '\x1b[31m',
    green: '\x1b[32m',
    yellow: '\x1b[33m',
    blue: '\x1b[34m',
    magenta: '\x1b[35m',
    cyan: '\x1b[36m',
    white: '\x1b[37m'
};

const logLevels = {
    error: 0,
    warn: 1,
    info: 2,
    debug: 3
};

const currentLogLevel = logLevels[config.logLevel] || logLevels.info;

function formatTimestamp() {
    return new Date().toISOString();
}

function log(level, message, ...args) {
    if (logLevels[level] > currentLogLevel) return;
    
    const timestamp = formatTimestamp();
    const levelUpper = level.toUpperCase();
    
    let color = colors.white;
    switch (level) {
        case 'error':
            color = colors.red;
            break;
        case 'warn':
            color = colors.yellow;
            break;
        case 'info':
            color = colors.green;
            break;
        case 'debug':
            color = colors.cyan;
            break;
    }
    
    console.log(
        `${colors.dim}[${timestamp}]${colors.reset} ` +
        `${color}${levelUpper}${colors.reset} ` +
        `${message}`,
        ...args
    );
}

module.exports = {
    error: (message, ...args) => log('error', message, ...args),
    warn: (message, ...args) => log('warn', message, ...args),
    info: (message, ...args) => log('info', message, ...args),
    debug: (message, ...args) => log('debug', message, ...args)
};
