const logger = require('./logger.js');

/**
 * Performance monitoring utility for bot operations
 */
class PerformanceMonitor {
    constructor() {
        this.metrics = {
            commandExecutions: new Map(),
            responseTimesMs: [],
            errorCount: 0,
            successCount: 0,
            startTime: Date.now()
        };
    }

    /**
     * Start monitoring a command execution
     * @param {string} commandName - Name of the command
     * @param {string} userId - User ID executing the command
     * @returns {Function} - End function to call when command completes
     */
    startCommand(commandName, userId) {
        const startTime = Date.now();
        const executionId = `${commandName}_${userId}_${startTime}`;
        
        return {
            end: (success = true, error = null) => {
                const duration = Date.now() - startTime;
                
                // Track command-specific metrics
                if (!this.metrics.commandExecutions.has(commandName)) {
                    this.metrics.commandExecutions.set(commandName, {
                        count: 0,
                        totalTime: 0,
                        errors: 0,
                        averageTime: 0
                    });
                }
                
                const commandMetrics = this.metrics.commandExecutions.get(commandName);
                commandMetrics.count++;
                commandMetrics.totalTime += duration;
                commandMetrics.averageTime = commandMetrics.totalTime / commandMetrics.count;
                
                if (success) {
                    this.metrics.successCount++;
                } else {
                    this.metrics.errorCount++;
                    commandMetrics.errors++;
                    
                    if (error) {
                        logger.error(`Command ${commandName} failed for ${userId}:`, error);
                    }
                }
                
                this.metrics.responseTimesMs.push(duration);
                
                // Keep only last 1000 response times to prevent memory issues
                if (this.metrics.responseTimesMs.length > 1000) {
                    this.metrics.responseTimesMs = this.metrics.responseTimesMs.slice(-1000);
                }
                
                // Log slow commands
                if (duration > 2000) {
                    logger.warn(`Slow command detected: ${commandName} took ${duration}ms`);
                }
            }
        };
    }

    /**
     * Get comprehensive performance statistics
     * @returns {Object} - Performance statistics
     */
    getStats() {
        const totalCommands = this.metrics.successCount + this.metrics.errorCount;
        const averageResponseTime = this.metrics.responseTimesMs.length > 0 
            ? this.metrics.responseTimesMs.reduce((a, b) => a + b, 0) / this.metrics.responseTimesMs.length 
            : 0;
        
        const uptime = Date.now() - this.metrics.startTime;
        const uptimeHours = Math.floor(uptime / (1000 * 60 * 60));
        const uptimeMinutes = Math.floor((uptime % (1000 * 60 * 60)) / (1000 * 60));
        
        return {
            totalCommands,
            successRate: totalCommands > 0 ? (this.metrics.successCount / totalCommands * 100).toFixed(2) : 100,
            errorRate: totalCommands > 0 ? (this.metrics.errorCount / totalCommands * 100).toFixed(2) : 0,
            averageResponseTime: Math.round(averageResponseTime),
            uptime: `${uptimeHours}h ${uptimeMinutes}m`,
            uptimeMs: uptime,
            commandBreakdown: Array.from(this.metrics.commandExecutions.entries()).map(([name, stats]) => ({
                command: name,
                executions: stats.count,
                averageTime: Math.round(stats.averageTime),
                errorRate: stats.count > 0 ? (stats.errors / stats.count * 100).toFixed(1) : '0.0'
            })).sort((a, b) => b.executions - a.executions) // Sort by most used
        };
    }

    /**
     * Get memory usage statistics
     * @returns {Object} - Memory usage information
     */
    getMemoryStats() {
        const usage = process.memoryUsage();
        return {
            heapUsed: Math.round(usage.heapUsed / 1024 / 1024), // MB
            heapTotal: Math.round(usage.heapTotal / 1024 / 1024), // MB
            external: Math.round(usage.external / 1024 / 1024), // MB
            rss: Math.round(usage.rss / 1024 / 1024), // MB
        };
    }

    /**
     * Check if bot performance is healthy
     * @returns {Object} - Health check results
     */
    healthCheck() {
        const stats = this.getStats();
        const memory = this.getMemoryStats();
        
        const issues = [];
        let status = 'healthy';
        
        // Check error rate
        if (parseFloat(stats.errorRate) > 5) {
            issues.push(`High error rate: ${stats.errorRate}%`);
            status = 'warning';
        }
        
        if (parseFloat(stats.errorRate) > 15) {
            status = 'critical';
        }
        
        // Check response time
        if (stats.averageResponseTime > 2000) {
            issues.push(`Slow response time: ${stats.averageResponseTime}ms`);
            status = status === 'critical' ? 'critical' : 'warning';
        }
        
        // Check memory usage (warning at 200MB, critical at 400MB)
        if (memory.heapUsed > 400) {
            issues.push(`Critical memory usage: ${memory.heapUsed}MB`);
            status = 'critical';
        } else if (memory.heapUsed > 200) {
            issues.push(`High memory usage: ${memory.heapUsed}MB`);
            status = status === 'critical' ? 'critical' : 'warning';
        }
        
        return {
            status,
            issues,
            summary: issues.length > 0 ? issues.join(', ') : 'All systems operational'
        };
    }

    /**
     * Reset all metrics (useful for testing or periodic resets)
     */
    reset() {
        this.metrics = {
            commandExecutions: new Map(),
            responseTimesMs: [],
            errorCount: 0,
            successCount: 0,
            startTime: Date.now()
        };
        logger.info('Performance metrics reset');
    }
}

// Export singleton instance
module.exports = new PerformanceMonitor();