const { EmbedBuilder } = require('discord.js');
const logger = require('./logger.js');

/**
 * Safely reply to an interaction with proper error handling
 * @param {CommandInteraction} interaction - Discord interaction
 * @param {Object} options - Reply options
 * @returns {Promise<void>}
 */
async function safeReply(interaction, options) {
    try {
        if (interaction.replied || interaction.deferred) {
            return await interaction.followUp(options);
        } else {
            return await interaction.reply(options);
        }
    } catch (error) {
        logger.error('Error in safe reply:', error);
        
        // Try alternative reply method
        try {
            if (!interaction.replied && !interaction.deferred) {
                await interaction.reply({
                    content: '❌ Error en la respuesta del bot.',
                    ephemeral: true
                });
            }
        } catch (fallbackError) {
            logger.error('Fallback reply also failed:', fallbackError);
        }
    }
}

/**
 * Defer reply with timeout protection
 * @param {CommandInteraction} interaction - Discord interaction
 * @param {boolean} ephemeral - Whether the reply should be ephemeral
 * @returns {Promise<void>}
 */
async function safeDeferReply(interaction, ephemeral = false) {
    try {
        if (!interaction.deferred && !interaction.replied) {
            await interaction.deferReply({ ephemeral });
        }
    } catch (error) {
        logger.error('Error deferring reply:', error);
    }
}

/**
 * Create a success embed with Kry branding
 * @param {string} title - Embed title
 * @param {string} description - Embed description
 * @param {Array} fields - Additional fields
 * @returns {EmbedBuilder}
 */
function createSuccessEmbed(title, description, fields = []) {
    const embed = new EmbedBuilder()
        .setTitle(`✅ ${title}`)
        .setDescription(description)
        .setColor(0x00FF00)
        .setFooter({ text: 'Developed by: Kry' })
        .setTimestamp();
    
    if (fields.length > 0) {
        embed.addFields(fields);
    }
    
    return embed;
}

/**
 * Create an error embed with Kry branding
 * @param {string} title - Embed title
 * @param {string} description - Embed description
 * @param {Array} fields - Additional fields
 * @returns {EmbedBuilder}
 */
function createErrorEmbed(title, description, fields = []) {
    const embed = new EmbedBuilder()
        .setTitle(`❌ ${title}`)
        .setDescription(description)
        .setColor(0xFF0000)
        .setFooter({ text: 'Developed by: Kry' })
        .setTimestamp();
    
    if (fields.length > 0) {
        embed.addFields(fields);
    }
    
    return embed;
}

/**
 * Create an info embed with Kry branding
 * @param {string} title - Embed title
 * @param {string} description - Embed description
 * @param {Array} fields - Additional fields
 * @returns {EmbedBuilder}
 */
function createInfoEmbed(title, description, fields = []) {
    const embed = new EmbedBuilder()
        .setTitle(`ℹ️ ${title}`)
        .setDescription(description)
        .setColor(0x0099FF)
        .setFooter({ text: 'Developed by: Kry' })
        .setTimestamp();
    
    if (fields.length > 0) {
        embed.addFields(fields);
    }
    
    return embed;
}

/**
 * Handle interaction timeouts and provide user feedback
 * @param {CommandInteraction} interaction - Discord interaction
 * @param {Function} commandFunction - The command function to execute
 * @param {number} timeoutMs - Timeout in milliseconds (default 2500ms)
 * @returns {Promise<void>}
 */
async function executeWithTimeout(interaction, commandFunction, timeoutMs = 2500) {
    const timeoutPromise = new Promise((_, reject) => {
        setTimeout(() => reject(new Error('Command timeout')), timeoutMs);
    });
    
    try {
        await Promise.race([
            commandFunction(),
            timeoutPromise
        ]);
    } catch (error) {
        if (error.message === 'Command timeout') {
            logger.warn(`Command ${interaction.commandName} timed out`);
            
            const timeoutEmbed = createErrorEmbed(
                'Tiempo de Espera Agotado',
                'El comando tardó demasiado en responder. Inténtalo de nuevo.',
                [{ name: '⏱️ Tiempo Límite', value: `${timeoutMs}ms`, inline: true }]
            );
            
            await safeReply(interaction, {
                embeds: [timeoutEmbed],
                ephemeral: true
            });
        } else {
            throw error; // Re-throw non-timeout errors
        }
    }
}

module.exports = {
    safeReply,
    safeDeferReply,
    createSuccessEmbed,
    createErrorEmbed,
    createInfoEmbed,
    executeWithTimeout
};