// CEO permission checking utility
const CEO_USER_ID = process.env.CEO_USER_ID || '1395630399497044018'; // Your user ID

/**
 * Check if user has CEO permissions
 * @param {GuildMember} member - The member to check
 * @param {User} user - The user object
 * @returns {boolean} - Whether the user has CEO permissions
 */
function isCEO(member, user) {
    if (!member || !user) return false;
    
    // Check if it's the specific CEO user
    if (user.id === CEO_USER_ID) return true;
    
    // Check if user has a CEO role
    if (member.roles.cache.some(role => 
        role.name.toLowerCase().includes('ceo') || 
        role.name.toLowerCase().includes('owner') ||
        role.name.toLowerCase().includes('founder')
    )) {
        return true;
    }
    
    // Check if user is server owner
    if (user.id === member.guild.ownerId) return true;
    
    return false;
}

/**
 * Check if interaction user has CEO permissions
 * @param {CommandInteraction} interaction - Discord interaction
 * @returns {boolean} - Whether the user has CEO permissions
 */
function checkCEOPermission(interaction) {
    if (!interaction.guild) return false;
    return isCEO(interaction.member, interaction.user);
}

/**
 * Reply with permission denied message
 * @param {CommandInteraction} interaction - Discord interaction
 */
async function denyCEOPermission(interaction) {
    const { EmbedBuilder } = require('discord.js');
    
    const deniedEmbed = new EmbedBuilder()
        .setTitle('🚫 Acceso Denegado')
        .setDescription('Este comando está restringido exclusivamente al CEO del servidor.')
        .addFields([
            { name: '👑 Roles Autorizados', value: 'CEO, Owner, Founder', inline: true },
            { name: '🔒 Seguridad', value: 'Máxima protección para comandos críticos', inline: true }
        ])
        .setColor(0xFF0000)
        .setFooter({ text: 'Developed by: Kry - Sistema de Seguridad CEO' })
        .setTimestamp();
    
    try {
        await interaction.reply({
            embeds: [deniedEmbed],
            ephemeral: true
        });
    } catch (error) {
        // Fallback to simple message if embed fails
        await interaction.reply({
            content: '❌ Este comando solo puede ser usado por el CEO.',
            ephemeral: true
        });
    }
}

module.exports = {
    isCEO,
    checkCEOPermission,
    denyCEOPermission,
    CEO_USER_ID
};