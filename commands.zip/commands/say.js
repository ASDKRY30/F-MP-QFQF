const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { checkCEOPermission, denyCEOPermission } = require('../utils/ceo-check.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('say')
        .setDescription('Hace que el bot diga algo')
        .addStringOption(option =>
            option.setName('message')
                .setDescription('El mensaje que quieres que diga el bot')
                .setRequired(true))
        .addChannelOption(option =>
            option.setName('channel')
                .setDescription('Canal donde enviar el mensaje (opcional)')
                .setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

    async execute(interaction) {
        // Check CEO permission
        if (!checkCEOPermission(interaction)) {
            return await denyCEOPermission(interaction);
        }
        
        const message = interaction.options.getString('message');
        const channel = interaction.options.getChannel('channel') || interaction.channel;

        try {
            await channel.send(message);
            await interaction.reply({ 
                content: `✅ Mensaje enviado en ${channel}`, 
                ephemeral: true 
            });
        } catch (error) {
            await interaction.reply({ 
                content: '❌ No pude enviar el mensaje en ese canal.', 
                ephemeral: true 
            });
        }
    },
};