const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('giveaway')
        .setDescription('Crea un sorteo')
        .addStringOption(option =>
            option.setName('prize')
                .setDescription('Premio del sorteo')
                .setRequired(true))
        .addIntegerOption(option =>
            option.setName('duration')
                .setDescription('Duración en minutos')
                .setMinValue(1)
                .setMaxValue(10080) // 1 week
                .setRequired(true))
        .addIntegerOption(option =>
            option.setName('winners')
                .setDescription('Número de ganadores (por defecto 1)')
                .setMinValue(1)
                .setMaxValue(20)
                .setRequired(false))
        .addChannelOption(option =>
            option.setName('channel')
                .setDescription('Canal donde hacer el sorteo (por defecto el actual)')
                .setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageEvents),

    async execute(interaction) {
        const prize = interaction.options.getString('prize');
        const duration = interaction.options.getInteger('duration');
        const winners = interaction.options.getInteger('winners') || 1;
        const channel = interaction.options.getChannel('channel') || interaction.channel;
        
        const endTime = Date.now() + (duration * 60 * 1000);
        
        const embed = new EmbedBuilder()
            .setColor(0xffd700)
            .setTitle('🎉 SORTEO')
            .setDescription(`**Premio:** ${prize}\n\n**Cómo participar:**\nReacciona con 🎉 para entrar al sorteo`)
            .addFields(
                { name: '👥 Ganadores', value: winners.toString(), inline: true },
                { name: '⏱️ Termina', value: `<t:${Math.floor(endTime / 1000)}:R>`, inline: true },
                { name: '🎭 Organizador', value: interaction.user.tag, inline: true },
                { name: '📊 Participantes', value: '0', inline: false }
            )
            .setTimestamp(endTime)
            .setFooter({ text: 'Termina' });

        const giveawayMessage = await channel.send({ embeds: [embed] });
        await giveawayMessage.react('🎉');

        await interaction.reply({ 
            content: `✅ Sorteo creado en ${channel}! Termina <t:${Math.floor(endTime / 1000)}:R>`,
            ephemeral: true 
        });

        // Set timeout to end giveaway
        setTimeout(async () => {
            try {
                const updatedMessage = await giveawayMessage.fetch();
                const reaction = updatedMessage.reactions.cache.get('🎉');
                
                if (!reaction) {
                    const noParticipantsEmbed = new EmbedBuilder()
                        .setColor(0xf04747)
                        .setTitle('🎉 Sorteo Terminado')
                        .setDescription(`**Premio:** ${prize}\n\n❌ **No hubo participantes válidos**`)
                        .addFields(
                            { name: '🎭 Organizador', value: interaction.user.tag, inline: true }
                        )
                        .setTimestamp()
                        .setFooter({ text: 'Sorteo terminado' });

                    return await updatedMessage.edit({ embeds: [noParticipantsEmbed] });
                }

                const users = await reaction.users.fetch();
                const participants = users.filter(user => !user.bot);
                
                if (participants.size === 0) {
                    const noParticipantsEmbed = new EmbedBuilder()
                        .setColor(0xf04747)
                        .setTitle('🎉 Sorteo Terminado')
                        .setDescription(`**Premio:** ${prize}\n\n❌ **No hubo participantes válidos**`)
                        .addFields(
                            { name: '🎭 Organizador', value: interaction.user.tag, inline: true }
                        )
                        .setTimestamp()
                        .setFooter({ text: 'Sorteo terminado' });

                    return await updatedMessage.edit({ embeds: [noParticipantsEmbed] });
                }

                // Select random winners
                const participantArray = Array.from(participants.values());
                const selectedWinners = [];
                const winnersCount = Math.min(winners, participantArray.length);
                
                for (let i = 0; i < winnersCount; i++) {
                    const randomIndex = Math.floor(Math.random() * participantArray.length);
                    const winner = participantArray.splice(randomIndex, 1)[0];
                    selectedWinners.push(winner);
                }

                const winnerMentions = selectedWinners.map(winner => `<@${winner.id}>`).join(', ');
                const winnerList = selectedWinners.map(winner => winner.tag).join('\n');

                const resultsEmbed = new EmbedBuilder()
                    .setColor(0x43b581)
                    .setTitle('🎉 Sorteo Terminado')
                    .setDescription(`**Premio:** ${prize}\n\n🏆 **Ganador${selectedWinners.length > 1 ? 'es' : ''}:**\n${winnerList}`)
                    .addFields(
                        { name: '👥 Participantes', value: participants.size.toString(), inline: true },
                        { name: '🏆 Ganadores', value: selectedWinners.length.toString(), inline: true },
                        { name: '🎭 Organizador', value: interaction.user.tag, inline: true }
                    )
                    .setTimestamp()
                    .setFooter({ text: 'Sorteo terminado' });

                await updatedMessage.edit({ embeds: [resultsEmbed] });
                
                // Send congratulations message
                await channel.send(`🎉 ¡Felicidades ${winnerMentions}! Has ganado: **${prize}**\n\nContacta al organizador ${interaction.user} para reclamar tu premio.`);
                
            } catch (error) {
                console.error('Error ending giveaway:', error);
            }
        }, duration * 60 * 1000);
    },
};