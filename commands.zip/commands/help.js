const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder } = require('discord.js');
const { createInfoEmbed, safeReply } = require('../utils/interaction-handler.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('help')
        .setDescription('Muestra información de ayuda del bot')
        .addStringOption(option =>
            option.setName('command')
                .setDescription('Comando específico del que obtener ayuda')
                .setRequired(false)),

    async execute(interaction) {
        const commandName = interaction.options.getString('command');

        if (commandName) {
            // Show specific command help
            const command = interaction.client.commands.get(commandName);
            if (!command) {
                return await safeReply(interaction, {
                    content: `❌ No se encontró el comando \`${commandName}\`.`,
                    ephemeral: true
                });
            }

            const embed = new EmbedBuilder()
                .setTitle(`📚 Ayuda: /${command.data.name}`)
                .setDescription(command.data.description)
                .addFields([
                    { name: '📝 Uso', value: `\`/${command.data.name}\``, inline: true },
                    { name: '🔒 Permisos', value: 'Solo CEO', inline: true }
                ])
                .setColor(0x7289DA)
                .setFooter({ text: 'Developed by: Kry' })
                .setTimestamp();

            return await safeReply(interaction, { embeds: [embed], ephemeral: true });
        }

        // Main comprehensive help embed
        const embed = new EmbedBuilder()
            .setTitle('📚 30K-BOT - Sistema de Gestión Completo')
            .setDescription(`
**🎯 Bot Especializado para Shops/Negocios**
Desarrollado por: **Kry** - Sistema CEO con máxima seguridad

**👑 Acceso Exclusivo CEO**
Todos los comandos requieren permisos de CEO para máxima protección.
            `)
            .addFields([
                {
                    name: '🛡️ **MODERACIÓN AVANZADA** (12 comandos)',
                    value: [
                        '`/ban` `/kick` `/mute` `/unmute` - Control de usuarios',
                        '`/clear` - Limpiar mensajes avanzado',
                        '`/modpro` - Suite de moderación profesional',
                        '`/antiraid` - Protección contra raids',
                        '`/security` - Panel de seguridad completo'
                    ].join('\n'),
                    inline: false
                },
                {
                    name: '🎫 **SISTEMA DE TICKETS** (1 comando)',
                    value: [
                        '`/ticket` - 4 categorías: **Buy**, **Support**, **Partner**, **HWID**'
                    ].join('\n'),
                    inline: false
                },
                {
                    name: '🎁 **SORTEOS AVANZADOS** (2 comandos)',
                    value: [
                        '`/giveaway` - Sorteos básicos',
                        '`/giveaway-pro` - Sistema profesional con reroll'
                    ].join('\n'),
                    inline: false
                },
                {
                    name: '🔧 **UTILIDADES & ADMIN** (8 comandos)',
                    value: [
                        '`/role` `/welcome` `/serverinfo` `/userinfo`',
                        '`/embed` `/say` `/avatar` `/weather`'
                    ].join('\n'),
                    inline: false
                },
                {
                    name: '🎮 **ENTRETENIMIENTO** (4 comandos)',
                    value: [
                        '`/8ball` `/coinflip` `/dice` `/poll`'
                    ].join('\n'),
                    inline: false
                },
                {
                    name: '⚙️ **SISTEMA CEO** (4 comandos)',
                    value: [
                        '`/botstats` `/debug` `/backup` `/ping`'
                    ].join('\n'),
                    inline: false
                },
                {
                    name: '📊 **ESTADÍSTICAS**',
                    value: [
                        `**Total:** ${interaction.client.commands.size} comandos`,
                        `**Servidores:** ${interaction.client.guilds.cache.size}`,
                        `**Estado:** 🟢 Online 24/7`
                    ].join('\n'),
                    inline: false
                }
            ])
            .setColor(0x7289DA)
            .setThumbnail(interaction.client.user.displayAvatarURL())
            .setFooter({ text: 'Developed by: Kry - Sistema de Ayuda' })
            .setTimestamp();

        await safeReply(interaction, { embeds: [embed], ephemeral: true });
    },
};