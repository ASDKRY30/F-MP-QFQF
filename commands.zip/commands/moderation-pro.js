const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { checkCEOPermission, denyCEOPermission } = require('../utils/ceo-check.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('modpro')
        .setDescription('Comandos avanzados de moderación (Solo CEO)')
        .addSubcommand(subcommand =>
            subcommand
                .setName('massban')
                .setDescription('Banear múltiples usuarios por ID')
                .addStringOption(option =>
                    option.setName('user_ids')
                        .setDescription('IDs de usuarios separados por comas')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('reason')
                        .setDescription('Razón del ban masivo')
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('nuke')
                .setDescription('Eliminar todos los mensajes del canal')
                .addIntegerOption(option =>
                    option.setName('messages')
                        .setDescription('Número de mensajes a eliminar (máximo 1000)')
                        .setMinValue(1)
                        .setMaxValue(1000)
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('lockdown')
                .setDescription('Bloquear el servidor completo'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('unlock')
                .setDescription('Desbloquear el servidor'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('purgeuser')
                .setDescription('Eliminar todos los mensajes de un usuario')
                .addUserOption(option =>
                    option.setName('user')
                        .setDescription('Usuario cuyos mensajes eliminar')
                        .setRequired(true))
                .addIntegerOption(option =>
                    option.setName('days')
                        .setDescription('Días hacia atrás para buscar (máximo 14)')
                        .setMinValue(1)
                        .setMaxValue(14)
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('slowmode')
                .setDescription('Configurar modo lento en el canal')
                .addIntegerOption(option =>
                    option.setName('seconds')
                        .setDescription('Segundos de cooldown (0 para desactivar)')
                        .setMinValue(0)
                        .setMaxValue(21600)
                        .setRequired(true)))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction) {
        // Check CEO permission
        if (!checkCEOPermission(interaction)) {
            return await denyCEOPermission(interaction);
        }

        const subcommand = interaction.options.getSubcommand();

        if (subcommand === 'massban') {
            await this.massBan(interaction);
        } else if (subcommand === 'nuke') {
            await this.nukeChannel(interaction);
        } else if (subcommand === 'lockdown') {
            await this.lockdownServer(interaction);
        } else if (subcommand === 'unlock') {
            await this.unlockServer(interaction);
        } else if (subcommand === 'purgeuser') {
            await this.purgeUser(interaction);
        } else if (subcommand === 'slowmode') {
            await this.setSlowmode(interaction);
        }
    },

    async massBan(interaction) {
        const userIds = interaction.options.getString('user_ids').split(',').map(id => id.trim());
        const reason = interaction.options.getString('reason') || 'Ban masivo por CEO';

        if (userIds.length > 20) {
            return await interaction.reply({
                content: '❌ Máximo 20 usuarios por ban masivo.',
                ephemeral: true
            });
        }

        await interaction.deferReply({ ephemeral: true });

        let successful = 0;
        let failed = 0;
        const results = [];

        for (const userId of userIds) {
            try {
                const user = await interaction.client.users.fetch(userId);
                await interaction.guild.members.ban(userId, { reason });
                successful++;
                results.push(`✅ ${user.tag} (${userId})`);
            } catch (error) {
                failed++;
                results.push(`❌ ${userId} - ${error.message}`);
            }
        }

        const embed = new EmbedBuilder()
            .setColor(successful > failed ? 0x43b581 : 0xf04747)
            .setTitle('⚡ Ban Masivo Completado')
            .setDescription(`**Exitosos:** ${successful}\n**Fallidos:** ${failed}\n\n${results.join('\n')}`)
            .addFields(
                { name: '📝 Razón', value: reason, inline: false }
            )
            .setFooter({ text: 'Developed by: Kry • Moderación Avanzada' })
            .setTimestamp();

        await interaction.editReply({ embeds: [embed] });
    },

    async nukeChannel(interaction) {
        const messagesToDelete = interaction.options.getInteger('messages') || 100;
        
        await interaction.deferReply({ ephemeral: true });

        try {
            let totalDeleted = 0;
            const channel = interaction.channel;

            // Delete messages in batches
            while (totalDeleted < messagesToDelete) {
                const limit = Math.min(100, messagesToDelete - totalDeleted);
                const messages = await channel.messages.fetch({ limit });
                
                if (messages.size === 0) break;

                const deleted = await channel.bulkDelete(messages, true);
                totalDeleted += deleted.size;

                if (deleted.size < messages.size) break; // No more messages to delete
            }

            const embed = new EmbedBuilder()
                .setColor(0xf04747)
                .setTitle('💥 Canal Nukeado')
                .setDescription(`Se eliminaron **${totalDeleted}** mensajes del canal.`)
                .addFields(
                    { name: '📊 Solicitado', value: messagesToDelete.toString(), inline: true },
                    { name: '🗑️ Eliminados', value: totalDeleted.toString(), inline: true },
                    { name: '👤 Ejecutado por', value: interaction.user.tag, inline: true }
                )
                .setFooter({ text: 'Developed by: Kry • Canal Nukeado' })
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });

        } catch (error) {
            await interaction.editReply({
                content: '❌ Error al nukear el canal. Algunos mensajes pueden ser muy antiguos.'
            });
        }
    },

    async lockdownServer(interaction) {
        await interaction.deferReply();

        try {
            const channels = interaction.guild.channels.cache.filter(c => c.type === 0);
            let locked = 0;

            for (const [, channel] of channels) {
                try {
                    await channel.permissionOverwrites.edit(interaction.guild.id, {
                        SendMessages: false,
                        AddReactions: false,
                        CreatePublicThreads: false,
                        CreatePrivateThreads: false
                    });
                    locked++;
                } catch (error) {
                    console.error(`Error locking channel ${channel.name}:`, error);
                }
            }

            const embed = new EmbedBuilder()
                .setColor(0xf04747)
                .setTitle('🔒 Servidor Bloqueado')
                .setDescription(`El servidor ha sido bloqueado por el CEO.`)
                .addFields(
                    { name: '📊 Canales bloqueados', value: `${locked}/${channels.size}`, inline: true },
                    { name: '👤 Ejecutado por', value: interaction.user.tag, inline: true },
                    { name: '⏰ Fecha', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
                )
                .setFooter({ text: 'Developed by: Kry • Lockdown activado' })
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });

        } catch (error) {
            await interaction.editReply({
                content: '❌ Error al bloquear el servidor.'
            });
        }
    },

    async unlockServer(interaction) {
        await interaction.deferReply();

        try {
            const channels = interaction.guild.channels.cache.filter(c => c.type === 0);
            let unlocked = 0;

            for (const [, channel] of channels) {
                try {
                    await channel.permissionOverwrites.edit(interaction.guild.id, {
                        SendMessages: null,
                        AddReactions: null,
                        CreatePublicThreads: null,
                        CreatePrivateThreads: null
                    });
                    unlocked++;
                } catch (error) {
                    console.error(`Error unlocking channel ${channel.name}:`, error);
                }
            }

            const embed = new EmbedBuilder()
                .setColor(0x43b581)
                .setTitle('🔓 Servidor Desbloqueado')
                .setDescription(`El servidor ha sido desbloqueado.`)
                .addFields(
                    { name: '📊 Canales desbloqueados', value: `${unlocked}/${channels.size}`, inline: true },
                    { name: '👤 Ejecutado por', value: interaction.user.tag, inline: true },
                    { name: '⏰ Fecha', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
                )
                .setFooter({ text: 'Developed by: Kry • Lockdown desactivado' })
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });

        } catch (error) {
            await interaction.editReply({
                content: '❌ Error al desbloquear el servidor.'
            });
        }
    },

    async purgeUser(interaction) {
        const targetUser = interaction.options.getUser('user');
        const days = interaction.options.getInteger('days') || 7;

        await interaction.deferReply({ ephemeral: true });

        try {
            const cutoff = Date.now() - (days * 24 * 60 * 60 * 1000);
            let totalDeleted = 0;
            
            const messages = await interaction.channel.messages.fetch({ limit: 100 });
            const userMessages = messages.filter(m => 
                m.author.id === targetUser.id && 
                m.createdTimestamp > cutoff
            );

            if (userMessages.size === 0) {
                return await interaction.editReply({
                    content: `❌ No se encontraron mensajes de ${targetUser.tag} en los últimos ${days} días.`
                });
            }

            await interaction.channel.bulkDelete(userMessages);
            totalDeleted = userMessages.size;

            const embed = new EmbedBuilder()
                .setColor(0xf04747)
                .setTitle('🧹 Purga de Usuario')
                .setDescription(`Se eliminaron **${totalDeleted}** mensajes de ${targetUser.tag}`)
                .addFields(
                    { name: '👤 Usuario', value: targetUser.tag, inline: true },
                    { name: '📅 Días', value: days.toString(), inline: true },
                    { name: '🗑️ Eliminados', value: totalDeleted.toString(), inline: true }
                )
                .setFooter({ text: 'Developed by: Kry • Purga completada' })
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });

        } catch (error) {
            await interaction.editReply({
                content: '❌ Error al purgar mensajes del usuario.'
            });
        }
    },

    async setSlowmode(interaction) {
        const seconds = interaction.options.getInteger('seconds');

        try {
            await interaction.channel.setRateLimitPerUser(seconds);

            const embed = new EmbedBuilder()
                .setColor(seconds > 0 ? 0xffa500 : 0x43b581)
                .setTitle(seconds > 0 ? '⏳ Modo Lento Activado' : '⏳ Modo Lento Desactivado')
                .setDescription(seconds > 0 ? 
                    `Los usuarios deben esperar **${seconds}** segundos entre mensajes.` :
                    `Se ha desactivado el modo lento en este canal.`)
                .addFields(
                    { name: '📊 Cooldown', value: seconds > 0 ? `${seconds} segundos` : 'Desactivado', inline: true },
                    { name: '👤 Configurado por', value: interaction.user.tag, inline: true }
                )
                .setFooter({ text: 'Developed by: Kry • Modo lento' })
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });

        } catch (error) {
            await interaction.reply({
                content: '❌ Error al configurar el modo lento.',
                ephemeral: true
            });
        }
    }
};