const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, ButtonBuilder, ButtonStyle, ChannelType, PermissionFlagsBits } = require('discord.js');
const { checkCEOPermission, denyCEOPermission } = require('../utils/ceo-check.js');
const fs = require('fs');
const path = require('path');

// Ticket configuration storage
const ticketConfig = new Map();
const activeTickets = new Map();
const configPath = path.join(__dirname, '../data/tickets.json');

function loadTicketConfig() {
    try {
        if (fs.existsSync(configPath)) {
            const data = fs.readFileSync(configPath, 'utf8');
            const configs = JSON.parse(data);
            for (const [guildId, config] of Object.entries(configs)) {
                ticketConfig.set(guildId, config);
            }
        }
    } catch (error) {
        console.error('Error loading ticket config:', error);
    }
}

function saveTicketConfig() {
    try {
        const dataDir = path.dirname(configPath);
        if (!fs.existsSync(dataDir)) {
            fs.mkdirSync(dataDir, { recursive: true });
        }
        const configs = Object.fromEntries(ticketConfig);
        fs.writeFileSync(configPath, JSON.stringify(configs, null, 2));
    } catch (error) {
        console.error('Error saving ticket config:', error);
    }
}

loadTicketConfig();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ticket')
        .setDescription('Sistema avanzado de tickets para shop (Solo CEO)')
        .addSubcommand(subcommand =>
            subcommand
                .setName('setup')
                .setDescription('Configura el sistema de tickets')
                .addChannelOption(option =>
                    option.setName('category')
                        .setDescription('Categoría donde crear los tickets')
                        .addChannelTypes(ChannelType.GuildCategory)
                        .setRequired(true))
                .addRoleOption(option =>
                    option.setName('support_role')
                        .setDescription('Rol del equipo de soporte')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('panel')
                .setDescription('Crea el panel de tickets'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('close')
                .setDescription('Cierra el ticket actual'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('add')
                .setDescription('Agrega un usuario al ticket')
                .addUserOption(option =>
                    option.setName('user')
                        .setDescription('Usuario a agregar')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('stats')
                .setDescription('Estadísticas del sistema de tickets')),

    async execute(interaction) {
        // Check CEO permission for all subcommands
        if (!checkCEOPermission(interaction)) {
            return await denyCEOPermission(interaction);
        }

        const subcommand = interaction.options.getSubcommand();
        const guildId = interaction.guild.id;

        switch (subcommand) {
            case 'setup':
                await this.setupTickets(interaction, guildId);
                break;
            case 'panel':
                await this.createPanel(interaction, guildId);
                break;
            case 'close':
                await this.closeTicket(interaction);
                break;
            case 'add':
                await this.addUserToTicket(interaction);
                break;
            case 'stats':
                await this.showStats(interaction, guildId);
                break;
            default:
                await interaction.reply({
                    content: '❌ Subcomando no reconocido.',
                    ephemeral: true
                });
        }
    },

    async setupTickets(interaction, guildId) {
        const category = interaction.options.getChannel('category');
        const supportRole = interaction.options.getRole('support_role');

        // Check if category is valid (either category type or we'll accept it)
        if (category.type !== ChannelType.GuildCategory && category.type !== 4) {
            return await interaction.reply({
                content: '❌ Debes seleccionar una categoría válida. El canal debe ser una categoría, no un canal de texto.',
                ephemeral: true
            });
        }

        const config = {
            categoryId: category.id,
            supportRoleId: supportRole.id,
            ticketCount: 0,
            totalTickets: 0,
            closedTickets: 0
        };

        ticketConfig.set(guildId, config);
        saveTicketConfig();

        const embed = new EmbedBuilder()
            .setTitle('✅ Sistema de Tickets Configurado')
            .setDescription('El sistema de tickets ha sido configurado exitosamente para tu shop.')
            .addFields([
                { name: '📂 Categoría', value: `${category}`, inline: true },
                { name: '👥 Rol de Soporte', value: `${supportRole}`, inline: true },
                { name: '🎯 Estado', value: '✅ Listo para usar', inline: true }
            ])
            .setColor(0x00FF00)
            .setFooter({ text: 'Developed by: Kry - Sistema de Tickets' })
            .setTimestamp();

        await interaction.reply({ embeds: [embed], ephemeral: true });
    },

    async createPanel(interaction, guildId) {
        const config = ticketConfig.get(guildId);
        if (!config) {
            return await interaction.reply({
                content: '❌ Primero configura el sistema con `/ticket setup`.',
                ephemeral: true
            });
        }

        const embed = new EmbedBuilder()
            .setTitle('🎫 SISTEMA DE TICKETS - 30K SHOP')
            .setDescription(`
**¡Bienvenido al sistema de tickets!**
Selecciona el tipo de asistencia que necesitas:

🛒 **BUY** - Compras y pedidos
• Consultas sobre productos
• Procesar compras
• Estado de pedidos

🛠️ **SUPPORT** - Soporte técnico
• Problemas técnicos
• Ayuda con configuración
• Resolución de errores

🤝 **PARTNER** - Colaboraciones
• Propuestas de partnership
• Colaboraciones comerciales
• Oportunidades de negocio

🔑 **HWID** - Gestión de HWID
• Problemas con HWID
• Reset de licencias
• Cambio de hardware

*Desarrollado por: **Kry** - Sistema Profesional*
            `)
            .setColor(0x7289DA)
            .setThumbnail(interaction.guild.iconURL())
            .setFooter({ 
                text: 'Developed by: Kry • Selecciona una opción para crear tu ticket',
                iconURL: interaction.client.user.displayAvatarURL() 
            })
            .setTimestamp();

        const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('ticket_create')
            .setPlaceholder('🎯 Selecciona el tipo de ticket...')
            .addOptions([
                {
                    label: 'BUY - Compras',
                    description: 'Compras, pedidos y consultas de productos',
                    value: 'buy',
                    emoji: '🛒'
                },
                {
                    label: 'SUPPORT - Soporte',
                    description: 'Soporte técnico y ayuda general',
                    value: 'support',
                    emoji: '🛠️'
                },
                {
                    label: 'PARTNER - Colaboración',
                    description: 'Partnerships y colaboraciones comerciales',
                    value: 'partner',
                    emoji: '🤝'
                },
                {
                    label: 'HWID - Gestión HWID',
                    description: 'Problemas con HWID y licencias',
                    value: 'hwid',
                    emoji: '🔑'
                }
            ]);

        const row = new ActionRowBuilder().addComponents(selectMenu);

        await interaction.reply({ 
            embeds: [embed], 
            components: [row],
            ephemeral: false
        });
    },

    async closeTicket(interaction) {
        const channelName = interaction.channel.name;
        
        if (!channelName.startsWith('ticket-')) {
            return await interaction.reply({
                content: '❌ Este comando solo puede usarse en canales de tickets.',
                ephemeral: true
            });
        }

        const embed = new EmbedBuilder()
            .setTitle('🔒 Cerrando Ticket')
            .setDescription('¿Estás seguro de que quieres cerrar este ticket?')
            .setColor(0xFFFF00)
            .setFooter({ text: 'Developed by: Kry - Cierre de Tickets' });

        const buttons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('confirm_close')
                    .setLabel('✅ Confirmar Cierre')
                    .setStyle(ButtonStyle.Danger),
                new ButtonBuilder()
                    .setCustomId('cancel_close')
                    .setLabel('❌ Cancelar')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.reply({ 
            embeds: [embed], 
            components: [buttons],
            ephemeral: true
        });
    },

    async addUserToTicket(interaction) {
        const user = interaction.options.getUser('user');
        const channelName = interaction.channel.name;
        
        if (!channelName.startsWith('ticket-')) {
            return await interaction.reply({
                content: '❌ Este comando solo puede usarse en canales de tickets.',
                ephemeral: true
            });
        }

        try {
            await interaction.channel.permissionOverwrites.create(user, {
                ViewChannel: true,
                SendMessages: true,
                ReadMessageHistory: true
            });

            const embed = new EmbedBuilder()
                .setTitle('✅ Usuario Agregado al Ticket')
                .setDescription(`${user} ha sido agregado a este ticket.`)
                .setColor(0x00FF00)
                .setFooter({ text: 'Developed by: Kry' })
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });
        } catch (error) {
            await interaction.reply({
                content: '❌ Error al agregar usuario al ticket.',
                ephemeral: true
            });
        }
    },

    async showStats(interaction, guildId) {
        const config = ticketConfig.get(guildId);
        if (!config) {
            return await interaction.reply({
                content: '❌ El sistema de tickets no está configurado.',
                ephemeral: true
            });
        }

        const ticketChannels = interaction.guild.channels.cache.filter(
            channel => channel.name.startsWith('ticket-')
        );

        const embed = new EmbedBuilder()
            .setTitle('📊 Estadísticas del Sistema de Tickets')
            .setDescription('Resumen completo del sistema de tickets')
            .addFields([
                { name: '🎫 Tickets Activos', value: ticketChannels.size.toString(), inline: true },
                { name: '📈 Total Creados', value: config.totalTickets.toString(), inline: true },
                { name: '✅ Cerrados', value: config.closedTickets.toString(), inline: true },
                { name: '📂 Categoría', value: `<#${config.categoryId}>`, inline: true },
                { name: '👥 Rol de Soporte', value: `<@&${config.supportRoleId}>`, inline: true },
                { name: '⚡ Estado', value: '🟢 Operativo', inline: true }
            ])
            .setColor(0x7289DA)
            .setFooter({ text: 'Developed by: Kry - Estadísticas de Tickets' })
            .setTimestamp();

        if (ticketChannels.size > 0) {
            const activeTicketsList = ticketChannels
                .map(channel => `• ${channel}`)
                .slice(0, 10)
                .join('\n');

            embed.addFields([{
                name: '📋 Tickets Activos',
                value: activeTicketsList + (ticketChannels.size > 10 ? `\n*...y ${ticketChannels.size - 10} más*` : ''),
                inline: false
            }]);
        }

        await interaction.reply({ embeds: [embed], ephemeral: true });
    },

    // Handle ticket creation from select menu
    async handleTicketCreation(interaction) {
        const guildId = interaction.guild.id;
        const config = ticketConfig.get(guildId);
        
        if (!config) {
            return await interaction.reply({
                content: '❌ Sistema de tickets no configurado.',
                ephemeral: true
            });
        }

        const ticketType = interaction.values[0];
        const user = interaction.user;
        
        // Check if user already has an open ticket
        const existingTicket = interaction.guild.channels.cache.find(
            channel => channel.name === `ticket-${user.username.toLowerCase()}-${ticketType}`
        );

        if (existingTicket) {
            return await interaction.reply({
                content: `❌ Ya tienes un ticket abierto: ${existingTicket}`,
                ephemeral: true
            });
        }

        try {
            // Create ticket channel
            const ticketChannel = await interaction.guild.channels.create({
                name: `ticket-${user.username.toLowerCase()}-${ticketType}`,
                type: ChannelType.GuildText,
                parent: config.categoryId,
                permissionOverwrites: [
                    {
                        id: interaction.guild.roles.everyone,
                        deny: [PermissionFlagsBits.ViewChannel]
                    },
                    {
                        id: user.id,
                        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory]
                    },
                    {
                        id: config.supportRoleId,
                        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.ManageMessages]
                    }
                ]
            });

            // Update stats
            config.totalTickets++;
            saveTicketConfig();

            // Create welcome embed
            const welcomeEmbed = new EmbedBuilder()
                .setTitle(`🎫 Ticket ${ticketType.toUpperCase()} Creado`)
                .setDescription(`
¡Hola ${user}! Tu ticket ha sido creado exitosamente.

**Tipo de ticket:** ${ticketType.toUpperCase()}
**Estado:** 🟢 Abierto
**Creado:** <t:${Math.floor(Date.now() / 1000)}:F>

Un miembro del equipo te atenderá pronto.
**Por favor describe tu consulta con el mayor detalle posible.**
                `)
                .setColor(0x00FF00)
                .setFooter({ text: 'Developed by: Kry - Sistema de Tickets' })
                .setTimestamp();

            const closeButton = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('close_ticket')
                        .setLabel('🔒 Cerrar Ticket')
                        .setStyle(ButtonStyle.Danger)
                );

            await ticketChannel.send({ 
                content: `${user} <@&${config.supportRoleId}>`,
                embeds: [welcomeEmbed], 
                components: [closeButton] 
            });

            await interaction.reply({
                content: `✅ Tu ticket ha sido creado: ${ticketChannel}`,
                ephemeral: true
            });

        } catch (error) {
            console.error('Error creating ticket:', error);
            await interaction.reply({
                content: '❌ Error al crear el ticket. Contacta con un administrador.',
                ephemeral: true
            });
        }
    }
};