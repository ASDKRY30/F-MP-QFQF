const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('weather')
        .setDescription('Obtiene información del clima de una ciudad')
        .addStringOption(option =>
            option.setName('city')
                .setDescription('Ciudad de la que obtener el clima')
                .setRequired(true)),

    async execute(interaction) {
        const city = interaction.options.getString('city');
        
        await interaction.deferReply();

        try {
            // Using a free weather API (OpenWeatherMap alternative)
            const response = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&appid=demo&units=metric&lang=es`);
            
            if (!response.ok) {
                const embed = new EmbedBuilder()
                    .setColor(0xf04747)
                    .setTitle('🌡️ Error de Clima')
                    .setDescription('No se pudo obtener información del clima. Esto puede deberse a:')
                    .addFields(
                        { name: '❌ Posibles causas', value: 
                            '• Ciudad no encontrada\n' +
                            '• API key no configurada\n' +
                            '• Servicio temporalmente no disponible', inline: false },
                        { name: '💡 Sugerencia', value: 'Intenta con el nombre completo de la ciudad o con el formato "Ciudad, País"', inline: false }
                    )
                    .setTimestamp();

                return await interaction.editReply({ embeds: [embed] });
            }

            const data = await response.json();
            
            const embed = new EmbedBuilder()
                .setColor(0x87ceeb)
                .setTitle(`🌡️ Clima en ${data.name}, ${data.sys.country}`)
                .setDescription(`**${data.weather[0].description.charAt(0).toUpperCase() + data.weather[0].description.slice(1)}**`)
                .addFields(
                    { name: '🌡️ Temperatura', value: `${Math.round(data.main.temp)}°C`, inline: true },
                    { name: '🤒 Se siente como', value: `${Math.round(data.main.feels_like)}°C`, inline: true },
                    { name: '💧 Humedad', value: `${data.main.humidity}%`, inline: true },
                    { name: '💨 Viento', value: `${data.wind.speed} m/s`, inline: true },
                    { name: '👁️ Visibilidad', value: `${(data.visibility / 1000).toFixed(1)} km`, inline: true },
                    { name: '🏔️ Presión', value: `${data.main.pressure} hPa`, inline: true }
                )
                .setThumbnail(`https://openweathermap.org/img/wn/${data.weather[0].icon}@2x.png`)
                .setTimestamp()
                .setFooter({ 
                    text: `Datos del clima • Actualizado`, 
                    iconURL: interaction.client.user.displayAvatarURL() 
                });

            await interaction.editReply({ embeds: [embed] });
            
        } catch (error) {
            const embed = new EmbedBuilder()
                .setColor(0xf04747)
                .setTitle('🌡️ Servicio de Clima No Disponible')
                .setDescription('El comando de clima requiere una API key válida de OpenWeatherMap.')
                .addFields(
                    { name: '🔧 Para activar esta función', value: 
                        '1. Obtén una API key gratuita en openweathermap.org\n' +
                        '2. Configúrala en las variables de entorno\n' +
                        '3. El comando funcionará automáticamente', inline: false },
                    { name: '💡 Mientras tanto', value: 'Puedes usar otros comandos del bot como `/serverinfo`, `/userinfo`, o `/ping`', inline: false }
                )
                .setTimestamp();

            await interaction.editReply({ embeds: [embed] });
        }
    },
};