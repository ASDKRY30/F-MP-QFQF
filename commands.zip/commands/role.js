const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { checkCEOPermission, denyCEOPermission } = require('../utils/ceo-check.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('role')
        .setDescription('Gestiona roles de usuarios')
        .addSubcommand(subcommand =>
            subcommand
                .setName('add')
                .setDescription('Agregar un rol a un usuario')
                .addUserOption(option =>
                    option.setName('user')
                        .setDescription('Usuario al que agregar el rol')
                        .setRequired(true))
                .addRoleOption(option =>
                    option.setName('role')
                        .setDescription('Rol a agregar')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('remove')
                .setDescription('Quitar un rol de un usuario')
                .addUserOption(option =>
                    option.setName('user')
                        .setDescription('Usuario al que quitar el rol')
                        .setRequired(true))
                .addRoleOption(option =>
                    option.setName('role')
                        .setDescription('Rol a quitar')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('create')
                .setDescription('Crear un nuevo rol')
                .addStringOption(option =>
                    option.setName('name')
                        .setDescription('Nombre del rol')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('color')
                        .setDescription('Color del rol (hex, ej: #FF0000)')
                        .setRequired(false))
                .addBooleanOption(option =>
                    option.setName('hoisted')
                        .setDescription('Mostrar el rol separado en la lista de miembros')
                        .setRequired(false))
                .addBooleanOption(option =>
                    option.setName('mentionable')
                        .setDescription('Permitir que el rol sea mencionable')
                        .setRequired(false)))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles),

    async execute(interaction) {
        // Check CEO permission
        if (!checkCEOPermission(interaction)) {
            return await denyCEOPermission(interaction);
        }
        
        const subcommand = interaction.options.getSubcommand();

        if (subcommand === 'add') {
            const user = interaction.options.getUser('user');
            const role = interaction.options.getRole('role');
            
            const member = await interaction.guild.members.fetch(user.id).catch(() => null);
            if (!member) {
                return await interaction.reply({
                    content: 'Usuario no encontrado en este servidor.',
                    ephemeral: true
                });
            }

            // Check if bot can manage this role
            if (role.position >= interaction.guild.members.me.roles.highest.position) {
                return await interaction.reply({
                    content: 'No puedo gestionar este rol porque es igual o superior al mío.',
                    ephemeral: true
                });
            }

            // Check if user can manage this role
            if (role.position >= interaction.member.roles.highest.position && interaction.user.id !== interaction.guild.ownerId) {
                return await interaction.reply({
                    content: 'No puedes gestionar un rol igual o superior al tuyo.',
                    ephemeral: true
                });
            }

            if (member.roles.cache.has(role.id)) {
                return await interaction.reply({
                    content: `${user.tag} ya tiene el rol ${role.name}.`,
                    ephemeral: true
                });
            }

            try {
                await member.roles.add(role);

                const embed = new EmbedBuilder()
                    .setColor(0x43b581)
                    .setTitle('✅ Rol Agregado')
                    .setDescription(`Se agregó el rol **${role.name}** a **${user.tag}**`)
                    .addFields(
                        { name: '👤 Usuario', value: `${user.tag}`, inline: true },
                        { name: '🏷️ Rol', value: `${role}`, inline: true },
                        { name: '👤 Moderador', value: `${interaction.user.tag}`, inline: true }
                    )
                    .setTimestamp();

                await interaction.reply({ embeds: [embed] });
            } catch (error) {
                await interaction.reply({
                    content: 'Hubo un error al agregar el rol.',
                    ephemeral: true
                });
            }

        } else if (subcommand === 'remove') {
            const user = interaction.options.getUser('user');
            const role = interaction.options.getRole('role');
            
            const member = await interaction.guild.members.fetch(user.id).catch(() => null);
            if (!member) {
                return await interaction.reply({
                    content: 'Usuario no encontrado en este servidor.',
                    ephemeral: true
                });
            }

            // Same permission checks as add
            if (role.position >= interaction.guild.members.me.roles.highest.position) {
                return await interaction.reply({
                    content: 'No puedo gestionar este rol porque es igual o superior al mío.',
                    ephemeral: true
                });
            }

            if (role.position >= interaction.member.roles.highest.position && interaction.user.id !== interaction.guild.ownerId) {
                return await interaction.reply({
                    content: 'No puedes gestionar un rol igual o superior al tuyo.',
                    ephemeral: true
                });
            }

            if (!member.roles.cache.has(role.id)) {
                return await interaction.reply({
                    content: `${user.tag} no tiene el rol ${role.name}.`,
                    ephemeral: true
                });
            }

            try {
                await member.roles.remove(role);

                const embed = new EmbedBuilder()
                    .setColor(0xf04747)
                    .setTitle('❌ Rol Removido')
                    .setDescription(`Se removió el rol **${role.name}** de **${user.tag}**`)
                    .addFields(
                        { name: '👤 Usuario', value: `${user.tag}`, inline: true },
                        { name: '🏷️ Rol', value: `${role}`, inline: true },
                        { name: '👤 Moderador', value: `${interaction.user.tag}`, inline: true }
                    )
                    .setTimestamp();

                await interaction.reply({ embeds: [embed] });
            } catch (error) {
                await interaction.reply({
                    content: 'Hubo un error al remover el rol.',
                    ephemeral: true
                });
            }

        } else if (subcommand === 'create') {
            const name = interaction.options.getString('name');
            const colorInput = interaction.options.getString('color');
            const hoisted = interaction.options.getBoolean('hoisted') || false;
            const mentionable = interaction.options.getBoolean('mentionable') || false;

            let color = null;
            if (colorInput) {
                const hexColor = colorInput.replace('#', '');
                if (/^[0-9A-F]{6}$/i.test(hexColor)) {
                    color = parseInt(hexColor, 16);
                }
            }

            try {
                const newRole = await interaction.guild.roles.create({
                    name: name,
                    color: color,
                    hoist: hoisted,
                    mentionable: mentionable,
                    reason: `Rol creado por ${interaction.user.tag}`
                });

                const embed = new EmbedBuilder()
                    .setColor(newRole.color || 0x7289da)
                    .setTitle('🎭 Nuevo Rol Creado')
                    .setDescription(`Se creó el rol **${newRole.name}** exitosamente`)
                    .addFields(
                        { name: '🏷️ Nombre', value: newRole.name, inline: true },
                        { name: '🎨 Color', value: newRole.hexColor, inline: true },
                        { name: '📌 Separado', value: hoisted ? 'Sí' : 'No', inline: true },
                        { name: '💬 Mencionable', value: mentionable ? 'Sí' : 'No', inline: true },
                        { name: '👤 Creado por', value: interaction.user.tag, inline: true },
                        { name: '🆔 ID', value: newRole.id, inline: true }
                    )
                    .setTimestamp();

                await interaction.reply({ embeds: [embed] });
            } catch (error) {
                await interaction.reply({
                    content: 'Hubo un error al crear el rol. Verifica que el nombre no esté en uso.',
                    ephemeral: true
                });
            }
        }
    },
};