const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('dice')
        .setDescription('Lanza dados')
        .addIntegerOption(option =>
            option.setName('sides')
                .setDescription('Número de caras del dado (por defecto 6)')
                .setMinValue(2)
                .setMaxValue(100)
                .setRequired(false))
        .addIntegerOption(option =>
            option.setName('count')
                .setDescription('Cantidad de dados a lanzar (por defecto 1)')
                .setMinValue(1)
                .setMaxValue(10)
                .setRequired(false)),

    async execute(interaction) {
        const sides = interaction.options.getInteger('sides') || 6;
        const count = interaction.options.getInteger('count') || 1;
        
        const results = [];
        let total = 0;
        
        for (let i = 0; i < count; i++) {
            const roll = Math.floor(Math.random() * sides) + 1;
            results.push(roll);
            total += roll;
        }
        
        const diceEmoji = ['⚀', '⚁', '⚂', '⚃', '⚄', '⚅'];
        const resultString = results.map(result => 
            sides === 6 && result <= 6 ? diceEmoji[result - 1] : `**${result}**`
        ).join(' ');
        
        const embed = new EmbedBuilder()
            .setColor(0x7289da)
            .setTitle('🎲 Lanzamiento de Dados')
            .setDescription(`Lanzando ${count} dado(s) de ${sides} caras`)
            .addFields(
                { name: '🎯 Resultados', value: resultString, inline: false },
                { name: '📊 Total', value: total.toString(), inline: true },
                { name: '📈 Promedio', value: (total / count).toFixed(2), inline: true },
                { name: '👤 Lanzado por', value: interaction.user.tag, inline: true }
            )
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });
    },
};