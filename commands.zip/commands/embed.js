const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { checkCEOPermission, denyCEOPermission } = require('../utils/ceo-check.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('embed')
        .setDescription('Crea un embed personalizado')
        .addStringOption(option =>
            option.setName('title')
                .setDescription('Título del embed')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('description')
                .setDescription('Descripción del embed')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('color')
                .setDescription('Color del embed (hex, ej: #FF0000)')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('image')
                .setDescription('URL de la imagen')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('thumbnail')
                .setDescription('URL del thumbnail')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('footer')
                .setDescription('Texto del footer')
                .setRequired(false))
        .addBooleanOption(option =>
            option.setName('timestamp')
                .setDescription('Agregar timestamp')
                .setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

    async execute(interaction) {
        // Check CEO permission
        if (!checkCEOPermission(interaction)) {
            return await denyCEOPermission(interaction);
        }
        
        const title = interaction.options.getString('title');
        const description = interaction.options.getString('description');
        const colorInput = interaction.options.getString('color');
        const image = interaction.options.getString('image');
        const thumbnail = interaction.options.getString('thumbnail');
        const footer = interaction.options.getString('footer');
        const timestamp = interaction.options.getBoolean('timestamp');

        // Parse color
        let color = 0x7289da; // Default Discord color
        if (colorInput) {
            const hexColor = colorInput.replace('#', '');
            if (/^[0-9A-F]{6}$/i.test(hexColor)) {
                color = parseInt(hexColor, 16);
            }
        }

        const embed = new EmbedBuilder()
            .setTitle(title)
            .setDescription(description)
            .setColor(color);

        if (image) embed.setImage(image);
        if (thumbnail) embed.setThumbnail(thumbnail);
        if (footer) embed.setFooter({ text: footer });
        if (timestamp) embed.setTimestamp();

        await interaction.reply({ embeds: [embed] });
    },
};