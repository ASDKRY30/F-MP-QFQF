const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { checkCEOPermission, denyCEOPermission } = require('../utils/ceo-check.js');
const fs = require('fs');
const path = require('path');

// Giveaway storage
const giveaways = new Map();
const giveawayPath = path.join(__dirname, '../data/giveaways.json');

function loadGiveaways() {
    try {
        if (fs.existsSync(giveawayPath)) {
            const data = fs.readFileSync(giveawayPath, 'utf8');
            const giveawayData = JSON.parse(data);
            for (const [messageId, giveaway] of Object.entries(giveawayData)) {
                giveaways.set(messageId, giveaway);
            }
        }
    } catch (error) {
        console.error('Error loading giveaways:', error);
    }
}

function saveGiveaways() {
    try {
        const dataDir = path.dirname(giveawayPath);
        if (!fs.existsSync(dataDir)) {
            fs.mkdirSync(dataDir, { recursive: true });
        }
        const giveawayData = Object.fromEntries(giveaways);
        fs.writeFileSync(giveawayPath, JSON.stringify(giveawayData, null, 2));
    } catch (error) {
        console.error('Error saving giveaways:', error);
    }
}

loadGiveaways();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('giveaway-pro')
        .setDescription('Sistema avanzado de sorteos (Solo CEO)')
        .addSubcommand(subcommand =>
            subcommand
                .setName('create')
                .setDescription('Crear un sorteo avanzado')
                .addStringOption(option =>
                    option.setName('prize')
                        .setDescription('Premio del sorteo')
                        .setRequired(true))
                .addIntegerOption(option =>
                    option.setName('duration')
                        .setDescription('Duración en minutos')
                        .setMinValue(1)
                        .setMaxValue(43200) // 30 days
                        .setRequired(true))
                .addIntegerOption(option =>
                    option.setName('winners')
                        .setDescription('Número de ganadores')
                        .setMinValue(1)
                        .setMaxValue(50)
                        .setRequired(false))
                .addChannelOption(option =>
                    option.setName('channel')
                        .setDescription('Canal del sorteo')
                        .setRequired(false))
                .addRoleOption(option =>
                    option.setName('required_role')
                        .setDescription('Rol requerido para participar')
                        .setRequired(false))
                .addIntegerOption(option =>
                    option.setName('min_level')
                        .setDescription('Nivel mínimo requerido')
                        .setMinValue(1)
                        .setMaxValue(100)
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('reroll')
                .setDescription('Hacer reroll de un sorteo')
                .addStringOption(option =>
                    option.setName('message_id')
                        .setDescription('ID del mensaje del sorteo')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('end')
                .setDescription('Terminar un sorteo inmediatamente')
                .addStringOption(option =>
                    option.setName('message_id')
                        .setDescription('ID del mensaje del sorteo')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('list')
                .setDescription('Ver sorteos activos'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('edit')
                .setDescription('Editar un sorteo existente')
                .addStringOption(option =>
                    option.setName('message_id')
                        .setDescription('ID del mensaje del sorteo')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('new_prize')
                        .setDescription('Nuevo premio')
                        .setRequired(false))
                .addIntegerOption(option =>
                    option.setName('new_winners')
                        .setDescription('Nuevo número de ganadores')
                        .setMinValue(1)
                        .setMaxValue(50)
                        .setRequired(false))),

    async execute(interaction) {
        // Check CEO permission
        if (!checkCEOPermission(interaction)) {
            return await denyCEOPermission(interaction);
        }

        const subcommand = interaction.options.getSubcommand();

        if (subcommand === 'create') {
            await this.createGiveaway(interaction);
        } else if (subcommand === 'reroll') {
            await this.rerollGiveaway(interaction);
        } else if (subcommand === 'end') {
            await this.endGiveaway(interaction);
        } else if (subcommand === 'list') {
            await this.listGiveaways(interaction);
        } else if (subcommand === 'edit') {
            await this.editGiveaway(interaction);
        }
    },

    async createGiveaway(interaction) {
        const prize = interaction.options.getString('prize');
        const duration = interaction.options.getInteger('duration');
        const winners = interaction.options.getInteger('winners') || 1;
        const channel = interaction.options.getChannel('channel') || interaction.channel;
        const requiredRole = interaction.options.getRole('required_role');
        const minLevel = interaction.options.getInteger('min_level');

        const endTime = Date.now() + (duration * 60 * 1000);

        let requirements = [];
        if (requiredRole) requirements.push(`Rol requerido: ${requiredRole}`);
        if (minLevel) requirements.push(`Nivel mínimo: ${minLevel}`);

        const embed = new EmbedBuilder()
            .setColor(0xffd700)
            .setTitle('🎉 SORTEO AVANZADO')
            .setDescription(`**🏆 Premio:** ${prize}\n\n` +
                `**📋 Cómo participar:**\n` +
                `• Reacciona con 🎉 para entrar\n` +
                `• Debes cumplir los requisitos\n` +
                (requirements.length > 0 ? `• ${requirements.join('\n• ')}\n` : '') +
                `\n**⏰ Termina:** <t:${Math.floor(endTime / 1000)}:R>`)
            .addFields(
                { name: '🏆 Ganadores', value: winners.toString(), inline: true },
                { name: '📊 Participantes', value: '0', inline: true },
                { name: '🎭 Organizador', value: interaction.user.tag, inline: true }
            )
            .setFooter({ text: 'Developed by: Kry • Reacciona con 🎉' })
            .setTimestamp(endTime);

        const giveawayMessage = await channel.send({ embeds: [embed] });
        await giveawayMessage.react('🎉');

        // Store giveaway data
        const giveawayData = {
            channelId: channel.id,
            messageId: giveawayMessage.id,
            guildId: interaction.guild.id,
            prize,
            winners,
            endTime,
            hostId: interaction.user.id,
            requiredRoleId: requiredRole?.id || null,
            minLevel: minLevel || null,
            active: true
        };

        giveaways.set(giveawayMessage.id, giveawayData);
        saveGiveaways();

        await interaction.reply({
            content: `✅ Sorteo creado en ${channel}! Termina <t:${Math.floor(endTime / 1000)}:R>`,
            ephemeral: true
        });

        // Set timeout to end giveaway
        setTimeout(() => {
            this.endGiveawayAutomatic(giveawayMessage.id);
        }, duration * 60 * 1000);
    },

    async rerollGiveaway(interaction) {
        const messageId = interaction.options.getString('message_id');
        const giveawayData = giveaways.get(messageId);

        if (!giveawayData) {
            return await interaction.reply({
                content: '❌ No se encontró el sorteo con ese ID.',
                ephemeral: true
            });
        }

        try {
            const channel = interaction.guild.channels.cache.get(giveawayData.channelId);
            const message = await channel.messages.fetch(messageId);
            const reaction = message.reactions.cache.get('🎉');

            if (!reaction) {
                return await interaction.reply({
                    content: '❌ No se encontraron reacciones en el sorteo.',
                    ephemeral: true
                });
            }

            const users = await reaction.users.fetch();
            const participants = users.filter(user => !user.bot);

            if (participants.size === 0) {
                return await interaction.reply({
                    content: '❌ No hay participantes válidos para reroll.',
                    ephemeral: true
                });
            }

            // Select new winners
            const participantArray = Array.from(participants.values());
            const selectedWinners = [];
            const winnersCount = Math.min(giveawayData.winners, participantArray.length);

            for (let i = 0; i < winnersCount; i++) {
                const randomIndex = Math.floor(Math.random() * participantArray.length);
                const winner = participantArray.splice(randomIndex, 1)[0];
                selectedWinners.push(winner);
            }

            const winnerMentions = selectedWinners.map(winner => `<@${winner.id}>`).join(', ');

            const rerollEmbed = new EmbedBuilder()
                .setColor(0x43b581)
                .setTitle('🎉 REROLL COMPLETADO')
                .setDescription(`**🏆 Premio:** ${giveawayData.prize}\n\n**🎊 Nuevos Ganadores:**\n${selectedWinners.map(w => w.tag).join('\n')}`)
                .addFields(
                    { name: '👥 Participantes', value: participants.size.toString(), inline: true },
                    { name: '🔄 Reroll por', value: interaction.user.tag, inline: true }
                )
                .setFooter({ text: 'Developed by: Kry • Reroll' })
                .setTimestamp();

            await channel.send(`🔄 **REROLL:** ${winnerMentions} - ¡Felicidades por ganar **${giveawayData.prize}**!`);
            await channel.send({ embeds: [rerollEmbed] });

            await interaction.reply({
                content: `✅ Reroll completado. Nuevos ganadores: ${winnerMentions}`,
                ephemeral: true
            });

        } catch (error) {
            console.error('Error in reroll:', error);
            await interaction.reply({
                content: '❌ Error al hacer reroll del sorteo.',
                ephemeral: true
            });
        }
    },

    async endGiveaway(interaction) {
        const messageId = interaction.options.getString('message_id');
        const giveawayData = giveaways.get(messageId);

        if (!giveawayData) {
            return await interaction.reply({
                content: '❌ No se encontró el sorteo con ese ID.',
                ephemeral: true
            });
        }

        await this.endGiveawayAutomatic(messageId);
        await interaction.reply({
            content: '✅ Sorteo terminado exitosamente.',
            ephemeral: true
        });
    },

    async listGiveaways(interaction) {
        const activeGiveaways = Array.from(giveaways.values()).filter(g => g.active && g.guildId === interaction.guild.id);

        if (activeGiveaways.length === 0) {
            return await interaction.reply({
                content: 'No hay sorteos activos en este servidor.',
                ephemeral: true
            });
        }

        const embed = new EmbedBuilder()
            .setColor(0x7289da)
            .setTitle('📋 Sorteos Activos')
            .setDescription(activeGiveaways.map(g => 
                `**${g.prize}**\n` +
                `ID: \`${g.messageId}\`\n` +
                `Termina: <t:${Math.floor(g.endTime / 1000)}:R>\n` +
                `Ganadores: ${g.winners}`
            ).join('\n\n'))
            .setFooter({ text: 'Developed by: Kry' })
            .setTimestamp();

        await interaction.reply({ embeds: [embed], ephemeral: true });
    },

    async editGiveaway(interaction) {
        const messageId = interaction.options.getString('message_id');
        const newPrize = interaction.options.getString('new_prize');
        const newWinners = interaction.options.getInteger('new_winners');

        const giveawayData = giveaways.get(messageId);

        if (!giveawayData) {
            return await interaction.reply({
                content: '❌ No se encontró el sorteo con ese ID.',
                ephemeral: true
            });
        }

        if (newPrize) giveawayData.prize = newPrize;
        if (newWinners) giveawayData.winners = newWinners;

        try {
            const channel = interaction.guild.channels.cache.get(giveawayData.channelId);
            const message = await channel.messages.fetch(messageId);

            const embed = new EmbedBuilder()
                .setColor(0xffd700)
                .setTitle('🎉 SORTEO AVANZADO (EDITADO)')
                .setDescription(`**🏆 Premio:** ${giveawayData.prize}\n\n` +
                    `**📋 Cómo participar:**\n` +
                    `• Reacciona con 🎉 para entrar\n\n` +
                    `**⏰ Termina:** <t:${Math.floor(giveawayData.endTime / 1000)}:R>`)
                .addFields(
                    { name: '🏆 Ganadores', value: giveawayData.winners.toString(), inline: true },
                    { name: '📊 Participantes', value: '0', inline: true },
                    { name: '🎭 Organizador', value: interaction.user.tag, inline: true }
                )
                .setFooter({ text: 'Developed by: Kry • Editado' })
                .setTimestamp(giveawayData.endTime);

            await message.edit({ embeds: [embed] });

            giveaways.set(messageId, giveawayData);
            saveGiveaways();

            await interaction.reply({
                content: '✅ Sorteo editado exitosamente.',
                ephemeral: true
            });

        } catch (error) {
            await interaction.reply({
                content: '❌ Error al editar el sorteo.',
                ephemeral: true
            });
        }
    },

    async endGiveawayAutomatic(messageId) {
        const giveawayData = giveaways.get(messageId);
        if (!giveawayData || !giveawayData.active) return;

        try {
            const guild = require('../index.js').client.guilds.cache.get(giveawayData.guildId);
            const channel = guild.channels.cache.get(giveawayData.channelId);
            const message = await channel.messages.fetch(messageId);
            const reaction = message.reactions.cache.get('🎉');

            if (!reaction) {
                const noParticipantsEmbed = new EmbedBuilder()
                    .setColor(0xf04747)
                    .setTitle('🎉 Sorteo Terminado')
                    .setDescription(`**🏆 Premio:** ${giveawayData.prize}\n\n❌ **No hubo participantes válidos**`)
                    .setFooter({ text: 'Developed by: Kry' })
                    .setTimestamp();

                await message.edit({ embeds: [noParticipantsEmbed] });
                giveawayData.active = false;
                saveGiveaways();
                return;
            }

            const users = await reaction.users.fetch();
            const participants = users.filter(user => !user.bot);

            if (participants.size === 0) {
                const noParticipantsEmbed = new EmbedBuilder()
                    .setColor(0xf04747)
                    .setTitle('🎉 Sorteo Terminado')
                    .setDescription(`**🏆 Premio:** ${giveawayData.prize}\n\n❌ **No hubo participantes válidos**`)
                    .setFooter({ text: 'Developed by: Kry' })
                    .setTimestamp();

                await message.edit({ embeds: [noParticipantsEmbed] });
                giveawayData.active = false;
                saveGiveaways();
                return;
            }

            // Select winners
            const participantArray = Array.from(participants.values());
            const selectedWinners = [];
            const winnersCount = Math.min(giveawayData.winners, participantArray.length);

            for (let i = 0; i < winnersCount; i++) {
                const randomIndex = Math.floor(Math.random() * participantArray.length);
                const winner = participantArray.splice(randomIndex, 1)[0];
                selectedWinners.push(winner);
            }

            const winnerMentions = selectedWinners.map(winner => `<@${winner.id}>`).join(', ');

            const resultsEmbed = new EmbedBuilder()
                .setColor(0x43b581)
                .setTitle('🎉 Sorteo Terminado')
                .setDescription(`**🏆 Premio:** ${giveawayData.prize}\n\n**🎊 Ganadores:**\n${selectedWinners.map(w => w.tag).join('\n')}`)
                .addFields(
                    { name: '👥 Participantes', value: participants.size.toString(), inline: true },
                    { name: '🏆 Ganadores', value: selectedWinners.length.toString(), inline: true }
                )
                .setFooter({ text: 'Developed by: Kry • Sorteo terminado' })
                .setTimestamp();

            await message.edit({ embeds: [resultsEmbed] });
            await channel.send(`🎉 **FELICIDADES** ${winnerMentions}! Has ganado: **${giveawayData.prize}**\n\nContacta al organizador para reclamar tu premio.`);

            giveawayData.active = false;
            saveGiveaways();

        } catch (error) {
            console.error('Error ending giveaway automatically:', error);
        }
    }
};