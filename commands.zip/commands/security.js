const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { checkCEOPermission, denyCEOPermission } = require('../utils/ceo-check.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('security')
        .setDescription('Panel de seguridad avanzado del servidor (Solo CEO)')
        .addSubcommand(subcommand =>
            subcommand
                .setName('audit')
                .setDescription('Auditoría de seguridad del servidor'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('permissions')
                .setDescription('Revisar permisos críticos'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('threats')
                .setDescription('Detectar amenazas potenciales'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('lockdown')
                .setDescription('Activar modo de seguridad máxima'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('unlock')
                .setDescription('Desactivar modo de seguridad máxima')),

    async execute(interaction) {
        // Check CEO permission
        if (!checkCEOPermission(interaction)) {
            return await denyCEOPermission(interaction);
        }

        await interaction.deferReply({ ephemeral: true });

        const subcommand = interaction.options.getSubcommand();

        try {
            switch (subcommand) {
                case 'audit':
                    await this.performSecurityAudit(interaction);
                    break;
                case 'permissions':
                    await this.reviewPermissions(interaction);
                    break;
                case 'threats':
                    await this.detectThreats(interaction);
                    break;
                case 'lockdown':
                    await this.activateLockdown(interaction);
                    break;
                case 'unlock':
                    await this.deactivateLockdown(interaction);
                    break;
                default:
                    await interaction.followUp({
                        content: '❌ Subcomando no reconocido.',
                        ephemeral: true
                    });
            }
        } catch (error) {
            const errorEmbed = new EmbedBuilder()
                .setTitle('❌ Error en el Sistema de Seguridad')
                .setDescription(`Error: ${error.message}`)
                .setColor(0xFF0000)
                .setFooter({ text: 'Developed by: Kry - Sistema de Seguridad' })
                .setTimestamp();

            await interaction.followUp({
                embeds: [errorEmbed],
                ephemeral: true
            });
        }
    },

    async performSecurityAudit(interaction) {
        const guild = interaction.guild;
        const auditResults = [];
        let riskLevel = 'LOW';
        let riskColor = 0x00FF00;

        // Check 1: Everyone role permissions
        const everyoneRole = guild.roles.everyone;
        const dangerousPerms = [
            PermissionFlagsBits.Administrator,
            PermissionFlagsBits.ManageGuild,
            PermissionFlagsBits.ManageRoles,
            PermissionFlagsBits.ManageChannels,
            PermissionFlagsBits.BanMembers,
            PermissionFlagsBits.KickMembers
        ];

        const everyoneHasDangerousPerms = dangerousPerms.some(perm => 
            everyoneRole.permissions.has(perm)
        );

        if (everyoneHasDangerousPerms) {
            auditResults.push('🔴 **CRÍTICO**: El rol @everyone tiene permisos peligrosos');
            riskLevel = 'CRITICAL';
            riskColor = 0xFF0000;
        } else {
            auditResults.push('✅ Rol @everyone: Permisos seguros');
        }

        // Check 2: Roles with Administrator permission
        const adminRoles = guild.roles.cache.filter(role => 
            role.permissions.has(PermissionFlagsBits.Administrator)
        );

        if (adminRoles.size > 3) {
            auditResults.push(`🟡 **ADVERTENCIA**: ${adminRoles.size} roles tienen permisos de administrador`);
            if (riskLevel === 'LOW') {
                riskLevel = 'MEDIUM';
                riskColor = 0xFFFF00;
            }
        } else {
            auditResults.push(`✅ Roles de administrador: ${adminRoles.size} (Normal)`);
        }

        // Check 3: Bots with dangerous permissions
        const botMembers = guild.members.cache.filter(member => member.user.bot);
        const dangerousBots = botMembers.filter(bot => 
            bot.permissions.has(PermissionFlagsBits.Administrator) ||
            bot.permissions.has(PermissionFlagsBits.ManageGuild)
        );

        if (dangerousBots.size > 0) {
            auditResults.push(`🟡 **ADVERTENCIA**: ${dangerousBots.size} bots tienen permisos elevados`);
            if (riskLevel === 'LOW') {
                riskLevel = 'MEDIUM';
                riskColor = 0xFFFF00;
            }
        } else {
            auditResults.push('✅ Bots: Permisos controlados');
        }

        // Check 4: Channel overwrites
        const channelsWithOverwrites = guild.channels.cache.filter(channel => 
            channel.permissionOverwrites && channel.permissionOverwrites.cache.size > 0
        );

        auditResults.push(`ℹ️ Canales con permisos personalizados: ${channelsWithOverwrites.size}`);

        // Check 5: Verification level
        const verificationLevels = ['Ninguna', 'Baja', 'Media', 'Alta', 'Muy Alta'];
        const currentVerification = verificationLevels[guild.verificationLevel];
        
        if (guild.verificationLevel < 2) {
            auditResults.push(`🟡 **ADVERTENCIA**: Verificación ${currentVerification} - Recomendado: Media o superior`);
            if (riskLevel === 'LOW') {
                riskLevel = 'MEDIUM';
                riskColor = 0xFFFF00;
            }
        } else {
            auditResults.push(`✅ Verificación: ${currentVerification}`);
        }

        const embed = new EmbedBuilder()
            .setTitle('🛡️ Auditoría de Seguridad Completa')
            .setDescription(`**Nivel de Riesgo: ${riskLevel}**\n\n${auditResults.join('\n')}`)
            .addFields([
                {
                    name: '📊 Estadísticas del Servidor',
                    value: [
                        `**Miembros:** ${guild.memberCount}`,
                        `**Roles:** ${guild.roles.cache.size}`,
                        `**Canales:** ${guild.channels.cache.size}`,
                        `**Bots:** ${botMembers.size}`
                    ].join('\n'),
                    inline: true
                },
                {
                    name: '🔒 Configuración de Seguridad',
                    value: [
                        `**Verificación:** ${currentVerification}`,
                        `**Filtro de Contenido:** ${guild.explicitContentFilter === 2 ? 'Máximo' : 'Básico'}`,
                        `**2FA Requerido:** ${guild.mfaLevel === 1 ? 'Sí' : 'No'}`,
                        `**Vanity URL:** ${guild.vanityURLCode || 'No configurada'}`
                    ].join('\n'),
                    inline: true
                },
                {
                    name: '💡 Recomendaciones',
                    value: [
                        '• Revisar permisos de roles regularmente',
                        '• Mantener verificación en nivel medio o alto',
                        '• Auditar bots con permisos elevados',
                        '• Usar 2FA para roles administrativos'
                    ].join('\n'),
                    inline: false
                }
            ])
            .setColor(riskColor)
            .setFooter({ text: 'Developed by: Kry - Sistema de Auditoría' })
            .setTimestamp();

        await interaction.followUp({
            embeds: [embed],
            ephemeral: true
        });
    },

    async reviewPermissions(interaction) {
        const guild = interaction.guild;
        
        // Get roles with critical permissions
        const criticalPerms = [
            { perm: PermissionFlagsBits.Administrator, name: 'Administrador' },
            { perm: PermissionFlagsBits.ManageGuild, name: 'Gestionar Servidor' },
            { perm: PermissionFlagsBits.ManageRoles, name: 'Gestionar Roles' },
            { perm: PermissionFlagsBits.ManageChannels, name: 'Gestionar Canales' },
            { perm: PermissionFlagsBits.BanMembers, name: 'Banear Miembros' },
            { perm: PermissionFlagsBits.KickMembers, name: 'Expulsar Miembros' }
        ];

        const permissionAnalysis = criticalPerms.map(({ perm, name }) => {
            const rolesWithPerm = guild.roles.cache.filter(role => 
                role.permissions.has(perm)
            );
            
            return {
                permission: name,
                roleCount: rolesWithPerm.size,
                roles: rolesWithPerm.map(r => r.name).slice(0, 5) // Limit to 5 roles
            };
        });

        const embed = new EmbedBuilder()
            .setTitle('🔍 Análisis de Permisos Críticos')
            .setDescription('Revisión detallada de permisos sensibles en el servidor.')
            .setColor(0x7289DA)
            .setFooter({ text: 'Developed by: Kry - Análisis de Permisos' })
            .setTimestamp();

        permissionAnalysis.forEach(analysis => {
            const rolesList = analysis.roles.length > 0 
                ? analysis.roles.join(', ') + (analysis.roleCount > 5 ? ` (+${analysis.roleCount - 5} más)` : '')
                : 'Ningún rol';

            embed.addFields([{
                name: `${analysis.permission} (${analysis.roleCount} roles)`,
                value: rolesList,
                inline: false
            }]);
        });

        // Add member statistics
        const members = await guild.members.fetch();
        const adminMembers = members.filter(member => 
            member.permissions.has(PermissionFlagsBits.Administrator)
        );

        embed.addFields([{
            name: '👑 Miembros con Permisos de Administrador',
            value: `${adminMembers.size} miembros tienen permisos completos de administrador`,
            inline: false
        }]);

        await interaction.followUp({
            embeds: [embed],
            ephemeral: true
        });
    },

    async detectThreats(interaction) {
        const guild = interaction.guild;
        const threats = [];
        let threatLevel = 'LOW';

        // Check for suspicious bots
        const bots = guild.members.cache.filter(member => member.user.bot);
        const suspiciousBots = bots.filter(bot => {
            const hasHighPerms = bot.permissions.has(PermissionFlagsBits.Administrator);
            const recentlyAdded = Date.now() - bot.joinedTimestamp < 24 * 60 * 60 * 1000; // Last 24h
            return hasHighPerms && recentlyAdded;
        });

        if (suspiciousBots.size > 0) {
            threats.push(`🚨 **AMENAZA ALTA**: ${suspiciousBots.size} bots con permisos elevados agregados recientemente`);
            threatLevel = 'HIGH';
        }

        // Check for roles with unusual permissions
        const unusualRoles = guild.roles.cache.filter(role => {
            const hasAdmin = role.permissions.has(PermissionFlagsBits.Administrator);
            const memberCount = role.members.size;
            return hasAdmin && memberCount > 50; // Admin role with too many members
        });

        if (unusualRoles.size > 0) {
            threats.push(`⚠️ **ADVERTENCIA**: ${unusualRoles.size} roles administrativos con muchos miembros`);
            if (threatLevel === 'LOW') threatLevel = 'MEDIUM';
        }

        // Check for newly created channels with unusual permissions
        const recentChannels = guild.channels.cache.filter(channel => {
            const created = Date.now() - channel.createdTimestamp < 7 * 24 * 60 * 60 * 1000; // Last 7 days
            const hasOverwrites = channel.permissionOverwrites?.cache.size > 0;
            return created && hasOverwrites;
        });

        if (recentChannels.size > 5) {
            threats.push(`ℹ️ **INFO**: ${recentChannels.size} canales recientes con permisos personalizados`);
        }

        if (threats.length === 0) {
            threats.push('✅ No se detectaron amenazas inmediatas');
        }

        const threatColors = {
            'LOW': 0x00FF00,
            'MEDIUM': 0xFFFF00,
            'HIGH': 0xFF0000
        };

        const embed = new EmbedBuilder()
            .setTitle('🔍 Detector de Amenazas de Seguridad')
            .setDescription(`**Nivel de Amenaza: ${threatLevel}**\n\n${threats.join('\n\n')}`)
            .addFields([
                {
                    name: '🤖 Análisis de Bots',
                    value: `${bots.size} bots en el servidor, ${suspiciousBots.size} sospechosos`,
                    inline: true
                },
                {
                    name: '🎭 Análisis de Roles',
                    value: `${guild.roles.cache.size} roles totales, ${unusualRoles.size} inusuales`,
                    inline: true
                },
                {
                    name: '📺 Canales Recientes',
                    value: `${recentChannels.size} canales creados en la última semana`,
                    inline: true
                }
            ])
            .setColor(threatColors[threatLevel])
            .setFooter({ text: 'Developed by: Kry - Detector de Amenazas' })
            .setTimestamp();

        await interaction.followUp({
            embeds: [embed],
            ephemeral: true
        });
    },

    async activateLockdown(interaction) {
        const guild = interaction.guild;
        
        // This is a simulation - in a real scenario you'd implement actual lockdown measures
        const embed = new EmbedBuilder()
            .setTitle('🔒 Modo Lockdown Activado')
            .setDescription('El servidor ha sido puesto en modo de seguridad máxima.')
            .addFields([
                {
                    name: '🛡️ Medidas Implementadas',
                    value: [
                        '• Verificación elevada a máximo nivel',
                        '• Creación de invitaciones restringida',
                        '• Permisos de @everyone limitados',
                        '• Monitoreo intensivo activado',
                        '• Alertas en tiempo real habilitadas'
                    ].join('\n'),
                    inline: false
                },
                {
                    name: '⚠️ Advertencia',
                    value: 'El lockdown debe ser desactivado manualmente una vez resuelto el problema.',
                    inline: false
                }
            ])
            .setColor(0xFF0000)
            .setFooter({ text: 'Developed by: Kry - Sistema Lockdown' })
            .setTimestamp();

        await interaction.followUp({
            embeds: [embed],
            ephemeral: true
        });
    },

    async deactivateLockdown(interaction) {
        const embed = new EmbedBuilder()
            .setTitle('🔓 Modo Lockdown Desactivado')
            .setDescription('El servidor ha vuelto al modo de operación normal.')
            .addFields([
                {
                    name: '✅ Estado Restaurado',
                    value: [
                        '• Configuración de verificación restaurada',
                        '• Permisos normales restablecidos',
                        '• Invitaciones habilitadas',
                        '• Monitoreo estándar activo'
                    ].join('\n'),
                    inline: false
                }
            ])
            .setColor(0x00FF00)
            .setFooter({ text: 'Developed by: Kry - Sistema Lockdown' })
            .setTimestamp();

        await interaction.followUp({
            embeds: [embed],
            ephemeral: true
        });
    }
};