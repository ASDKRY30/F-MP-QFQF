const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('avatar')
        .setDescription('Muestra el avatar de un usuario')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('Usuario del que mostrar el avatar')
                .setRequired(false)),

    async execute(interaction) {
        const user = interaction.options.getUser('user') || interaction.user;
        
        const embed = new EmbedBuilder()
            .setColor(0x7289da)
            .setTitle(`🖼️ Avatar de ${user.tag}`)
            .setImage(user.displayAvatarURL({ dynamic: true, size: 512 }))
            .addFields(
                { name: '👤 Usuario', value: user.tag, inline: true },
                { name: '🆔 ID', value: user.id, inline: true },
                { name: '🔗 Enlaces', value: 
                    `[PNG](${user.displayAvatarURL({ format: 'png', size: 512 })}) • ` +
                    `[JPG](${user.displayAvatarURL({ format: 'jpg', size: 512 })}) • ` +
                    `[WEBP](${user.displayAvatarURL({ format: 'webp', size: 512 })})` +
                    (user.avatar && user.avatar.startsWith('a_') ? ` • [GIF](${user.displayAvatarURL({ format: 'gif', size: 512 })})` : ''),
                    inline: false
                }
            )
            .setTimestamp()
            .setFooter({ 
                text: `Solicitado por ${interaction.user.tag}`, 
                iconURL: interaction.user.displayAvatarURL() 
            });

        await interaction.reply({ embeds: [embed] });
    },
};