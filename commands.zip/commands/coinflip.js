const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('coinflip')
        .setDescription('Lanza una moneda al aire'),

    async execute(interaction) {
        const isHeads = Math.random() < 0.5;
        const result = isHeads ? 'Cara' : 'Cruz';
        const emoji = isHeads ? '🪙' : '⚫';
        
        const embed = new EmbedBuilder()
            .setColor(isHeads ? 0xffd700 : 0x708090)
            .setTitle('🪙 Lanzamiento de Moneda')
            .setDescription(`${emoji} **${result}**`)
            .addFields(
                { name: '🎯 Resultado', value: result, inline: true },
                { name: '👤 Lanzado por', value: interaction.user.tag, inline: true }
            )
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });
    },
};