const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { checkCEOPermission, denyCEOPermission } = require('../utils/ceo-check.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ping')
        .setDescription('Muestra el ping del bot y estado del sistema'),

    async execute(interaction) {
        // Check CEO permission
        if (!checkCEOPermission(interaction)) {
            return await denyCEOPermission(interaction);
        }
        
        const startTime = Date.now();
        
        // Send initial response
        await interaction.reply({ content: '🏓 Calculando ping y estado del sistema...', ephemeral: true });
        
        const endTime = Date.now();
        const ping = endTime - startTime;
        const apiPing = Math.round(interaction.client.ws.ping);
        
        // Determine status color based on ping
        let statusColor = 0x00FF00; // Green
        let statusText = 'Excelente';
        
        if (ping > 200 || apiPing > 200) {
            statusColor = 0xFFFF00; // Yellow
            statusText = 'Moderado';
        }
        
        if (ping > 500 || apiPing > 500) {
            statusColor = 0xFF0000; // Red
            statusText = 'Lento';
        }
        
        const embed = new EmbedBuilder()
            .setTitle('🏓 Estado del Bot - 30K-BOT')
            .setDescription(`**Estado del Sistema:** ${statusText}`)
            .addFields([
                { name: '⏱️ Latencia de Respuesta', value: `${ping}ms`, inline: true },
                { name: '💓 Latencia de la API', value: `${apiPing}ms`, inline: true },
                { name: '🌐 Estado de la Conexión', value: '🟢 Conectado', inline: true },
                { name: '🔧 Comandos Cargados', value: `${interaction.client.commands.size}`, inline: true },
                { name: '🏠 Servidores Activos', value: `${interaction.client.guilds.cache.size}`, inline: true },
                { name: '👥 Usuarios Totales', value: `${interaction.client.guilds.cache.reduce((acc, guild) => acc + guild.memberCount, 0)}`, inline: true },
                { name: '⚡ Tiempo de Actividad', value: `${Math.floor(process.uptime() / 3600)}h ${Math.floor((process.uptime() % 3600) / 60)}m`, inline: true },
                { name: '💾 Uso de Memoria', value: `${Math.round(process.memoryUsage().heapUsed / 1024 / 1024)}MB`, inline: true },
                { name: '🔒 Sistema CEO', value: '✅ Activo', inline: true }
            ])
            .setColor(statusColor)
            .setTimestamp()
            .setFooter({ text: 'Developed by: Kry - Sistema de Monitoreo' })
            .setThumbnail(interaction.client.user.displayAvatarURL());

        await interaction.editReply({ content: null, embeds: [embed] });
    },
};
