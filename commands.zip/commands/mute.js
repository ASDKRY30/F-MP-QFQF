const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { hasPermission, isHigherRole } = require('../utils/permissions.js');
const { checkCEOPermission, denyCEOPermission } = require('../utils/ceo-check.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('mute')
        .setDescription('Silencia a un miembro del servidor')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('El usuario a silenciar')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('duration')
                .setDescription('Duración del silencio (ej: 1h, 30m, 2d)')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('Razón del silencio')
                .setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

    async execute(interaction) {
        // Check CEO permission
        if (!checkCEOPermission(interaction)) {
            return await denyCEOPermission(interaction);
        }
        
        const targetUser = interaction.options.getUser('user');
        const duration = interaction.options.getString('duration') || '1h';
        const reason = interaction.options.getString('reason') || 'No se proporcionó razón';

        if (!interaction.guild) {
            return await interaction.reply({
                content: 'Este comando solo se puede usar en un servidor.',
                ephemeral: true
            });
        }

        // Check bot permissions
        if (!hasPermission(interaction.guild.members.me, PermissionFlagsBits.ModerateMembers)) {
            return await interaction.reply({
                content: 'No tengo permisos para silenciar miembros.',
                ephemeral: true
            });
        }

        const targetMember = await interaction.guild.members.fetch(targetUser.id).catch(() => null);
        
        if (!targetMember) {
            return await interaction.reply({
                content: 'Usuario no encontrado en este servidor.',
                ephemeral: true
            });
        }

        // Prevent self-mute
        if (targetUser.id === interaction.user.id) {
            return await interaction.reply({
                content: 'No puedes silenciarte a ti mismo.',
                ephemeral: true
            });
        }

        // Check role hierarchy
        if (!isHigherRole(interaction.member, targetMember)) {
            return await interaction.reply({
                content: 'No puedes silenciar a alguien con un rol igual o superior al tuyo.',
                ephemeral: true
            });
        }

        // Parse duration
        const timeMs = parseDuration(duration);
        if (!timeMs) {
            return await interaction.reply({
                content: 'Formato de duración inválido. Usa: 1h, 30m, 2d, etc.',
                ephemeral: true
            });
        }

        try {
            await targetMember.timeout(timeMs, reason);

            const embed = new EmbedBuilder()
                .setColor(0xffa500)
                .setTitle('🔇 Usuario Silenciado')
                .setDescription(`**${targetUser.tag}** ha sido silenciado exitosamente.`)
                .addFields(
                    { name: '👤 Usuario', value: `${targetUser.tag} (${targetUser.id})`, inline: true },
                    { name: '⏱️ Duración', value: duration, inline: true },
                    { name: '📝 Razón', value: reason, inline: false },
                    { name: '🔓 Termina', value: `<t:${Math.floor((Date.now() + timeMs) / 1000)}:F>`, inline: false }
                )
                .setTimestamp()
                .setFooter({ 
                    text: `Silenciado por ${interaction.user.tag}`, 
                    iconURL: interaction.user.displayAvatarURL() 
                });

            await interaction.reply({ embeds: [embed] });

            // Try to DM the user
            try {
                const dmEmbed = new EmbedBuilder()
                    .setColor(0xffa500)
                    .setTitle('🔇 Has sido silenciado')
                    .setDescription(`Has sido silenciado en **${interaction.guild.name}**`)
                    .addFields(
                        { name: '⏱️ Duración', value: duration, inline: true },
                        { name: '📝 Razón', value: reason, inline: true },
                        { name: '👤 Moderador', value: interaction.user.tag, inline: true }
                    )
                    .setTimestamp();

                await targetUser.send({ embeds: [dmEmbed] });
            } catch (error) {
                // User has DMs disabled
            }

        } catch (error) {
            await interaction.reply({
                content: 'Hubo un error al intentar silenciar al usuario.',
                ephemeral: true
            });
        }
    },
};

function parseDuration(duration) {
    const regex = /^(\d+)([smhd])$/;
    const match = duration.match(regex);
    
    if (!match) return null;
    
    const value = parseInt(match[1]);
    const unit = match[2];
    
    switch (unit) {
        case 's': return value * 1000;
        case 'm': return value * 60 * 1000;
        case 'h': return value * 60 * 60 * 1000;
        case 'd': return value * 24 * 60 * 60 * 1000;
        default: return null;
    }
}