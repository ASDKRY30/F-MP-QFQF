const { SlashCommandBuilder, EmbedBuilder, AttachmentBuilder } = require('discord.js');
const { checkCEOPermission, denyCEOPermission } = require('../utils/ceo-check.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('backup')
        .setDescription('Sistema de respaldo completo del bot (Solo CEO)')
        .addSubcommand(subcommand =>
            subcommand
                .setName('create')
                .setDescription('Crear respaldo completo de la configuración'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('export')
                .setDescription('Exportar configuración como archivo'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('info')
                .setDescription('Información del sistema de respaldo')),

    async execute(interaction) {
        // Check CEO permission
        if (!checkCEOPermission(interaction)) {
            return await denyCEOPermission(interaction);
        }

        await interaction.deferReply({ ephemeral: true });

        const subcommand = interaction.options.getSubcommand();

        try {
            switch (subcommand) {
                case 'create':
                    await this.createBackup(interaction);
                    break;
                case 'export':
                    await this.exportConfig(interaction);
                    break;
                case 'info':
                    await this.showBackupInfo(interaction);
                    break;
                default:
                    await interaction.followUp({
                        content: '❌ Subcomando no reconocido.',
                        ephemeral: true
                    });
            }
        } catch (error) {
            const errorEmbed = new EmbedBuilder()
                .setTitle('❌ Error en el Sistema de Respaldo')
                .setDescription(`Error: ${error.message}`)
                .setColor(0xFF0000)
                .setFooter({ text: 'Developed by: Kry - Sistema de Respaldo' })
                .setTimestamp();

            await interaction.followUp({
                embeds: [errorEmbed],
                ephemeral: true
            });
        }
    },

    async createBackup(interaction) {
        const backupData = {
            timestamp: new Date().toISOString(),
            bot: {
                name: interaction.client.user.tag,
                id: interaction.client.user.id,
                commands: interaction.client.commands.size,
                guilds: interaction.client.guilds.cache.size,
                users: interaction.client.guilds.cache.reduce((acc, guild) => acc + guild.memberCount, 0)
            },
            system: {
                nodeVersion: process.version,
                platform: process.platform,
                uptime: process.uptime(),
                memory: process.memoryUsage()
            },
            guilds: Array.from(interaction.client.guilds.cache.values()).map(guild => ({
                id: guild.id,
                name: guild.name,
                memberCount: guild.memberCount,
                channelCount: guild.channels.cache.size,
                roleCount: guild.roles.cache.size,
                ownerId: guild.ownerId
            })),
            commands: Array.from(interaction.client.commands.values()).map(cmd => ({
                name: cmd.data.name,
                description: cmd.data.description,
                options: cmd.data.options ? cmd.data.options.length : 0
            }))
        };

        // Save to data directory
        const backupDir = './data/backups';
        if (!fs.existsSync(backupDir)) {
            fs.mkdirSync(backupDir, { recursive: true });
        }

        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        const backupFile = path.join(backupDir, `backup-${timestamp}.json`);
        
        fs.writeFileSync(backupFile, JSON.stringify(backupData, null, 2));

        const embed = new EmbedBuilder()
            .setTitle('✅ Respaldo Creado Exitosamente')
            .setDescription('Se ha creado un respaldo completo del estado actual del bot.')
            .addFields([
                { name: '📁 Archivo', value: `backup-${timestamp}.json`, inline: true },
                { name: '📊 Comandos', value: backupData.bot.commands.toString(), inline: true },
                { name: '🏠 Servidores', value: backupData.bot.guilds.toString(), inline: true },
                { name: '👥 Usuarios', value: backupData.bot.users.toString(), inline: true },
                { name: '💾 Tamaño', value: `${Math.round(JSON.stringify(backupData).length / 1024)} KB`, inline: true },
                { name: '⏰ Fecha', value: `<t:${Math.floor(Date.now() / 1000)}:F>`, inline: true }
            ])
            .setColor(0x00FF00)
            .setFooter({ text: 'Developed by: Kry - Sistema de Respaldo' })
            .setTimestamp();

        await interaction.followUp({
            embeds: [embed],
            ephemeral: true
        });
    },

    async exportConfig(interaction) {
        const configData = {
            botInfo: {
                name: interaction.client.user.tag,
                id: interaction.client.user.id,
                created: interaction.client.user.createdAt.toISOString(),
                exportDate: new Date().toISOString()
            },
            statistics: {
                guilds: interaction.client.guilds.cache.size,
                users: interaction.client.guilds.cache.reduce((acc, guild) => acc + guild.memberCount, 0),
                commands: interaction.client.commands.size,
                channels: interaction.client.channels.cache.size
            },
            commandsList: Array.from(interaction.client.commands.values()).map(cmd => ({
                name: cmd.data.name,
                description: cmd.data.description,
                type: 'SlashCommand'
            })),
            systemInfo: {
                nodeVersion: process.version,
                platform: process.platform,
                architecture: process.arch,
                uptime: Math.floor(process.uptime()),
                memory: {
                    used: Math.round(process.memoryUsage().heapUsed / 1024 / 1024),
                    total: Math.round(process.memoryUsage().heapTotal / 1024 / 1024)
                }
            },
            metadata: {
                developer: 'Kry',
                version: '1.0.0',
                discordJsVersion: '14.x',
                description: '30K-BOT - Sistema completo de gestión para Discord'
            }
        };

        const configJson = JSON.stringify(configData, null, 2);
        const attachment = new AttachmentBuilder(Buffer.from(configJson), { 
            name: `30k-bot-config-${Date.now()}.json` 
        });

        const embed = new EmbedBuilder()
            .setTitle('📤 Configuración Exportada')
            .setDescription('Archivo de configuración completo del bot.')
            .addFields([
                { name: '📋 Contenido', value: 'Información completa del bot, comandos y estadísticas', inline: false },
                { name: '💾 Formato', value: 'JSON estructurado', inline: true },
                { name: '📏 Tamaño', value: `${Math.round(configJson.length / 1024)} KB`, inline: true }
            ])
            .setColor(0x7289DA)
            .setFooter({ text: 'Developed by: Kry - Exportación de Configuración' })
            .setTimestamp();

        await interaction.followUp({
            embeds: [embed],
            files: [attachment],
            ephemeral: true
        });
    },

    async showBackupInfo(interaction) {
        const backupDir = './data/backups';
        let backupFiles = [];
        let totalSize = 0;

        if (fs.existsSync(backupDir)) {
            backupFiles = fs.readdirSync(backupDir)
                .filter(file => file.endsWith('.json'))
                .map(file => {
                    const filePath = path.join(backupDir, file);
                    const stats = fs.statSync(filePath);
                    totalSize += stats.size;
                    return {
                        name: file,
                        size: Math.round(stats.size / 1024),
                        created: stats.birthtime
                    };
                })
                .sort((a, b) => b.created - a.created);
        }

        const embed = new EmbedBuilder()
            .setTitle('📋 Sistema de Respaldo - Información')
            .setDescription('Estado actual del sistema de respaldo del bot.')
            .addFields([
                { name: '📁 Directorio', value: backupDir, inline: true },
                { name: '📊 Total de Respaldos', value: backupFiles.length.toString(), inline: true },
                { name: '💾 Espacio Total', value: `${Math.round(totalSize / 1024)} KB`, inline: true }
            ])
            .setColor(0x00FFFF)
            .setFooter({ text: 'Developed by: Kry - Info del Sistema de Respaldo' })
            .setTimestamp();

        if (backupFiles.length > 0) {
            const recentBackups = backupFiles.slice(0, 5).map(backup => 
                `**${backup.name}** (${backup.size} KB)\n<t:${Math.floor(backup.created.getTime() / 1000)}:R>`
            ).join('\n\n');

            embed.addFields([{
                name: '🕒 Respaldos Recientes',
                value: recentBackups,
                inline: false
            }]);
        } else {
            embed.addFields([{
                name: '⚠️ Estado',
                value: 'No se han encontrado respaldos. Usa `/backup create` para crear uno.',
                inline: false
            }]);
        }

        // Add recommendations
        embed.addFields([{
            name: '💡 Recomendaciones',
            value: [
                '• Crear respaldos regulares antes de actualizaciones',
                '• Exportar configuración antes de cambios importantes',
                '• Mantener al menos 3 respaldos recientes',
                '• Verificar la integridad de los respaldos periódicamente'
            ].join('\n'),
            inline: false
        }]);

        await interaction.followUp({
            embeds: [embed],
            ephemeral: true
        });
    }
};