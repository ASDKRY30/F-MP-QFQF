const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const { checkCEOPermission, denyCEOPermission } = require('../utils/ceo-check.js');
const fs = require('fs');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('mercadopago')
        .setDescription('Sistema de auto-entregas con MercadoPago (Solo CEO)')
        .addSubcommand(subcommand =>
            subcommand
                .setName('setup')
                .setDescription('Configurar credenciales de MercadoPago'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('create-product')
                .setDescription('Crear producto para venta automática')
                .addStringOption(option =>
                    option.setName('name')
                        .setDescription('Nombre del producto')
                        .setRequired(true))
                .addNumberOption(option =>
                    option.setName('price')
                        .setDescription('Precio del producto')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('description')
                        .setDescription('Descripción del producto')
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('products')
                .setDescription('Ver todos los productos configurados'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('sales')
                .setDescription('Ver historial de ventas'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('config')
                .setDescription('Configurar canal de entregas y notificaciones')),

    async execute(interaction) {
        // Check CEO permission
        if (!checkCEOPermission(interaction)) {
            return await denyCEOPermission(interaction);
        }

        await interaction.deferReply({ ephemeral: true });

        const subcommand = interaction.options.getSubcommand();

        try {
            switch (subcommand) {
                case 'setup':
                    await this.setupMercadoPago(interaction);
                    break;
                case 'create-product':
                    await this.createProduct(interaction);
                    break;
                case 'products':
                    await this.showProducts(interaction);
                    break;
                case 'sales':
                    await this.showSales(interaction);
                    break;
                case 'config':
                    await this.configureSettings(interaction);
                    break;
                default:
                    await interaction.followUp({
                        content: '❌ Subcomando no reconocido.',
                        ephemeral: true
                    });
            }
        } catch (error) {
            const errorEmbed = new EmbedBuilder()
                .setTitle('❌ Error en MercadoPago')
                .setDescription(`Error: ${error.message}`)
                .setColor(0xFF0000)
                .setFooter({ text: 'Developed by: Kry - Sistema MercadoPago' })
                .setTimestamp();

            await interaction.followUp({
                embeds: [errorEmbed],
                ephemeral: true
            });
        }
    },

    async setupMercadoPago(interaction) {
        const embed = new EmbedBuilder()
            .setTitle('🔧 Configuración de MercadoPago')
            .setDescription(`
**Para configurar MercadoPago necesitas:**

1. **Access Token** - Token de acceso de tu cuenta MercadoPago
2. **Public Key** - Clave pública para transacciones
3. **Webhook URL** - URL donde MercadoPago enviará notificaciones

**Pasos para obtener credenciales:**
1. Ve a [developers.mercadopago.com](https://developers.mercadopago.com)
2. Crea una aplicación
3. Obtén tus credenciales de prueba/producción
4. Usa el botón de abajo para configurarlas

**⚠️ IMPORTANTE:** 
- Usa credenciales de PRUEBA primero
- Nunca compartas tus credenciales
- Las credenciales se guardan de forma segura
            `)
            .addFields([
                {
                    name: '🔐 Configuración Actual',
                    value: this.checkMercadoPagoConfig() ? '✅ Configurado' : '❌ Sin configurar',
                    inline: true
                },
                {
                    name: '🌐 Webhook',
                    value: `${process.env.REPLIT_DEV_DOMAIN || 'tu-repl'}.replit.dev/webhook/mercadopago`,
                    inline: true
                },
                {
                    name: '📊 Estado',
                    value: 'Sistema listo para configurar',
                    inline: true
                }
            ])
            .setColor(0x00D4FF)
            .setFooter({ text: 'Developed by: Kry - Configuración MercadoPago' })
            .setTimestamp();

        const button = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('setup_mp_credentials')
                    .setLabel('⚙️ Configurar Credenciales')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('test_mp_connection')
                    .setLabel('🧪 Probar Conexión')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.followUp({
            embeds: [embed],
            components: [button],
            ephemeral: true
        });
    },

    async createProduct(interaction) {
        const name = interaction.options.getString('name');
        const price = interaction.options.getNumber('price');
        const description = interaction.options.getString('description');

        // Ensure data directory exists
        const dataDir = './data';
        const productsFile = './data/products.json';
        
        if (!fs.existsSync(dataDir)) {
            fs.mkdirSync(dataDir, { recursive: true });
        }

        // Load existing products or create empty array
        let products = [];
        if (fs.existsSync(productsFile)) {
            products = JSON.parse(fs.readFileSync(productsFile, 'utf8'));
        }

        // Create new product
        const product = {
            id: `prod_${Date.now()}`,
            name: name,
            price: price,
            description: description,
            created: new Date().toISOString(),
            active: true,
            sales: 0
        };

        products.push(product);
        fs.writeFileSync(productsFile, JSON.stringify(products, null, 2));

        const embed = new EmbedBuilder()
            .setTitle('✅ Producto Creado')
            .setDescription('El producto ha sido agregado al sistema de auto-entregas.')
            .addFields([
                { name: '📦 Producto', value: name, inline: true },
                { name: '💰 Precio', value: `$${price}`, inline: true },
                { name: '🆔 ID', value: product.id, inline: true },
                { name: '📝 Descripción', value: description, inline: false },
                { name: '🎯 Estado', value: '✅ Activo', inline: true },
                { name: '📊 Ventas', value: '0', inline: true }
            ])
            .setColor(0x00FF00)
            .setFooter({ text: 'Developed by: Kry - Sistema de Productos' })
            .setTimestamp();

        const buttons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId(`create_payment_${product.id}`)
                    .setLabel('💳 Crear Link de Pago')
                    .setStyle(ButtonStyle.Success),
                new ButtonBuilder()
                    .setCustomId(`edit_product_${product.id}`)
                    .setLabel('✏️ Editar Producto')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.followUp({
            embeds: [embed],
            components: [buttons],
            ephemeral: true
        });
    },

    async showProducts(interaction) {
        const productsFile = './data/products.json';
        let products = [];
        
        if (fs.existsSync(productsFile)) {
            products = JSON.parse(fs.readFileSync(productsFile, 'utf8'));
        }

        if (products.length === 0) {
            const embed = new EmbedBuilder()
                .setTitle('📦 Lista de Productos')
                .setDescription('No hay productos configurados. Usa `/mercadopago create-product` para crear uno.')
                .setColor(0xFFFF00)
                .setFooter({ text: 'Developed by: Kry - Sistema de Productos' })
                .setTimestamp();

            return await interaction.followUp({
                embeds: [embed],
                ephemeral: true
            });
        }

        const embed = new EmbedBuilder()
            .setTitle('📦 Lista de Productos Configurados')
            .setDescription(`Total de productos: **${products.length}**`)
            .setColor(0x7289DA)
            .setFooter({ text: 'Developed by: Kry - Lista de Productos' })
            .setTimestamp();

        // Add products as fields
        products.forEach((product, index) => {
            embed.addFields([{
                name: `${index + 1}. ${product.name} ${product.active ? '✅' : '❌'}`,
                value: [
                    `**💰 Precio:** $${product.price}`,
                    `**🆔 ID:** \`${product.id}\``,
                    `**📊 Ventas:** ${product.sales || 0}`,
                    `**📝 Descripción:** ${product.description.substring(0, 50)}...`
                ].join('\n'),
                inline: true
            }]);
        });

        const buttons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('refresh_products')
                    .setLabel('🔄 Actualizar')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('export_products')
                    .setLabel('📤 Exportar')
                    .setStyle(ButtonStyle.Primary)
            );

        await interaction.followUp({
            embeds: [embed],
            components: [buttons],
            ephemeral: true
        });
    },

    async showSales(interaction) {
        const salesFile = './data/sales.json';
        let sales = [];
        
        if (fs.existsSync(salesFile)) {
            sales = JSON.parse(fs.readFileSync(salesFile, 'utf8'));
        }

        const totalSales = sales.length;
        const totalRevenue = sales.reduce((sum, sale) => sum + (sale.amount || 0), 0);
        const recentSales = sales.slice(-5).reverse(); // Last 5 sales

        const embed = new EmbedBuilder()
            .setTitle('📊 Historial de Ventas')
            .setDescription(`Sistema de auto-entregas MercadoPago`)
            .addFields([
                { name: '💰 Ingresos Totales', value: `$${totalRevenue.toFixed(2)}`, inline: true },
                { name: '🛒 Total de Ventas', value: totalSales.toString(), inline: true },
                { name: '📈 Promedio por Venta', value: totalSales > 0 ? `$${(totalRevenue/totalSales).toFixed(2)}` : '$0', inline: true }
            ])
            .setColor(0x00FF7F)
            .setFooter({ text: 'Developed by: Kry - Historial de Ventas' })
            .setTimestamp();

        if (recentSales.length > 0) {
            const recentSalesText = recentSales.map((sale, index) => 
                `**${index + 1}.** ${sale.product_name} - $${sale.amount} - <t:${Math.floor(new Date(sale.date).getTime() / 1000)}:R>`
            ).join('\n');

            embed.addFields([{
                name: '🕐 Ventas Recientes',
                value: recentSalesText,
                inline: false
            }]);
        } else {
            embed.addFields([{
                name: '📝 Estado',
                value: 'No hay ventas registradas aún.',
                inline: false
            }]);
        }

        await interaction.followUp({
            embeds: [embed],
            ephemeral: true
        });
    },

    async configureSettings(interaction) {
        const embed = new EmbedBuilder()
            .setTitle('⚙️ Configuración del Sistema de Auto-Entregas')
            .setDescription('Configura canales y ajustes del sistema MercadoPago')
            .addFields([
                {
                    name: '📢 Canal de Entregas',
                    value: 'Canal donde se enviarán los productos automáticamente',
                    inline: false
                },
                {
                    name: '🔔 Canal de Notificaciones',
                    value: 'Canal para notificaciones de ventas y admin',
                    inline: false
                },
                {
                    name: '🎯 Configuración Actual',
                    value: 'Sistema en modo configuración',
                    inline: false
                }
            ])
            .setColor(0x9966CC)
            .setFooter({ text: 'Developed by: Kry - Configuración Sistema' })
            .setTimestamp();

        const buttons = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('set_delivery_channel')
                    .setLabel('📦 Canal de Entregas')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('set_notification_channel')
                    .setLabel('🔔 Canal de Notificaciones')
                    .setStyle(ButtonStyle.Secondary),
                new ButtonBuilder()
                    .setCustomId('test_delivery_system')
                    .setLabel('🧪 Probar Sistema')
                    .setStyle(ButtonStyle.Success)
            );

        await interaction.followUp({
            embeds: [embed],
            components: [buttons],
            ephemeral: true
        });
    },

    checkMercadoPagoConfig() {
        // Check if MercadoPago is configured
        return process.env.MERCADOPAGO_ACCESS_TOKEN && process.env.MERCADOPAGO_PUBLIC_KEY;
    }
};