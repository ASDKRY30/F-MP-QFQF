const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { hasPermission } = require('../utils/permissions.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('unmute')
        .setDescription('Quita el silencio a un miembro del servidor')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('El usuario al que quitar el silencio')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('Razón para quitar el silencio')
                .setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers),

    async execute(interaction) {
        const targetUser = interaction.options.getUser('user');
        const reason = interaction.options.getString('reason') || 'No se proporcionó razón';

        if (!interaction.guild) {
            return await interaction.reply({
                content: 'Este comando solo se puede usar en un servidor.',
                ephemeral: true
            });
        }

        // Check bot permissions
        if (!hasPermission(interaction.guild.members.me, PermissionFlagsBits.ModerateMembers)) {
            return await interaction.reply({
                content: 'No tengo permisos para quitar silencios.',
                ephemeral: true
            });
        }

        const targetMember = await interaction.guild.members.fetch(targetUser.id).catch(() => null);
        
        if (!targetMember) {
            return await interaction.reply({
                content: 'Usuario no encontrado en este servidor.',
                ephemeral: true
            });
        }

        if (!targetMember.isCommunicationDisabled()) {
            return await interaction.reply({
                content: 'Este usuario no está silenciado.',
                ephemeral: true
            });
        }

        try {
            await targetMember.timeout(null, reason);

            const embed = new EmbedBuilder()
                .setColor(0x43b581)
                .setTitle('🔊 Silencio Removido')
                .setDescription(`**${targetUser.tag}** ya no está silenciado.`)
                .addFields(
                    { name: '👤 Usuario', value: `${targetUser.tag} (${targetUser.id})`, inline: true },
                    { name: '📝 Razón', value: reason, inline: true },
                    { name: '👤 Moderador', value: interaction.user.tag, inline: true }
                )
                .setTimestamp()
                .setFooter({ 
                    text: `Silencio removido por ${interaction.user.tag}`, 
                    iconURL: interaction.user.displayAvatarURL() 
                });

            await interaction.reply({ embeds: [embed] });

            // Try to DM the user
            try {
                const dmEmbed = new EmbedBuilder()
                    .setColor(0x43b581)
                    .setTitle('🔊 Tu silencio ha sido removido')
                    .setDescription(`Tu silencio en **${interaction.guild.name}** ha sido removido`)
                    .addFields(
                        { name: '📝 Razón', value: reason, inline: true },
                        { name: '👤 Moderador', value: interaction.user.tag, inline: true }
                    )
                    .setTimestamp();

                await targetUser.send({ embeds: [dmEmbed] });
            } catch (error) {
                // User has DMs disabled
            }

        } catch (error) {
            await interaction.reply({
                content: 'Hubo un error al intentar quitar el silencio.',
                ephemeral: true
            });
        }
    },
};