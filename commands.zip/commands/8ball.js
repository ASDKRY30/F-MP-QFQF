const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

const responses = [
    // Respuestas positivas
    "✅ Sí, definitivamente",
    "✅ Es cierto",
    "✅ Sin duda alguna",
    "✅ Sí, sin dudas",
    "✅ Puedes confiar en ello",
    "✅ Como yo lo veo, sí",
    "✅ Muy probable",
    "✅ Las perspectivas son buenas",
    "✅ Sí",
    "✅ Los signos apuntan a que sí",
    
    // Respuestas neutrales/indecisas
    "⚪ Respuesta confusa, intenta de nuevo",
    "⚪ Pregunta de nuevo más tarde",
    "⚪ Mejor no te lo digo ahora",
    "⚪ No puedo predecir ahora",
    "⚪ Concéntrate y pregunta de nuevo",
    
    // Respuestas negativas
    "❌ No cuentes con ello",
    "❌ Mi respuesta es no",
    "❌ Mis fuentes dicen que no",
    "❌ Las perspectivas no son tan buenas",
    "❌ Muy dudoso"
];

module.exports = {
    data: new SlashCommandBuilder()
        .setName('8ball')
        .setDescription('Haz una pregunta a la bola mágica')
        .addStringOption(option =>
            option.setName('question')
                .setDescription('Tu pregunta para la bola mágica')
                .setRequired(true)),

    async execute(interaction) {
        const question = interaction.options.getString('question');
        const response = responses[Math.floor(Math.random() * responses.length)];
        
        const embed = new EmbedBuilder()
            .setColor(response.startsWith('✅') ? 0x43b581 : response.startsWith('❌') ? 0xf04747 : 0xffa500)
            .setTitle('🎱 Bola Mágica 8')
            .addFields(
                { name: '❓ Pregunta', value: question, inline: false },
                { name: '🔮 Respuesta', value: response, inline: false }
            )
            .setTimestamp()
            .setFooter({ 
                text: `Preguntado por ${interaction.user.tag}`, 
                iconURL: interaction.user.displayAvatarURL() 
            });

        await interaction.reply({ embeds: [embed] });
    },
};