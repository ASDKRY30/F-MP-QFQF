const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { hasPermission, isHigherRole } = require('../utils/permissions.js');
const { checkCEOPermission, denyCEOPermission } = require('../utils/ceo-check.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ban')
        .setDescription('Ban a member from the server')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('The user to ban')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('Reason for the ban')
                .setRequired(false))
        .addIntegerOption(option =>
            option.setName('delete_days')
                .setDescription('Number of days of messages to delete (0-7)')
                .setMinValue(0)
                .setMaxValue(7)
                .setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers),
    
    async execute(interaction) {
        // Check CEO permission
        if (!checkCEOPermission(interaction)) {
            return await denyCEOPermission(interaction);
        }
        
        const targetUser = interaction.options.getUser('user');
        const reason = interaction.options.getString('reason') || 'No reason provided';
        const deleteDays = interaction.options.getInteger('delete_days') || 0;
        
        // Check if command is used in a guild
        if (!interaction.guild) {
            return await interaction.reply({
                content: 'This command can only be used in a server!',
                ephemeral: true
            });
        }

        // Check bot permissions
        if (!hasPermission(interaction.guild.members.me, PermissionFlagsBits.BanMembers)) {
            return await interaction.reply({
                content: 'I don\'t have permission to ban members!',
                ephemeral: true
            });
        }

        // Get target member (if they're in the server)
        const targetMember = await interaction.guild.members.fetch(targetUser.id).catch(() => null);
        
        // Prevent self-ban
        if (targetUser.id === interaction.user.id) {
            return await interaction.reply({
                content: 'You cannot ban yourself!',
                ephemeral: true
            });
        }

        // Prevent banning the bot owner
        if (targetUser.id === interaction.guild.ownerId) {
            return await interaction.reply({
                content: 'You cannot ban the server owner!',
                ephemeral: true
            });
        }

        // If member is in server, check additional restrictions
        if (targetMember) {
            // Check if target is bannable
            if (!targetMember.bannable) {
                return await interaction.reply({
                    content: 'I cannot ban this user! They may have higher permissions than me.',
                    ephemeral: true
                });
            }

            // Check role hierarchy
            const executorMember = interaction.member;
            if (!isHigherRole(executorMember, targetMember)) {
                return await interaction.reply({
                    content: 'You cannot ban someone with an equal or higher role than yours!',
                    ephemeral: true
                });
            }
        }

        try {
            // Send DM to user before banning (optional)
            try {
                await targetUser.send(
                    `You have been banned from **${interaction.guild.name}**\n` +
                    `**Reason:** ${reason}\n` +
                    `**Banned by:** ${interaction.user.tag}`
                );
            } catch (error) {
                // Ignore DM errors (user might have DMs disabled)
            }

            // Ban the user
            await interaction.guild.members.ban(targetUser, {
                reason: reason,
                deleteMessageDays: deleteDays
            });

            await interaction.reply({
                content: `✅ Successfully banned **${targetUser.tag}**\n` +
                         `**Reason:** ${reason}\n` +
                         `**Messages deleted:** ${deleteDays} day${deleteDays !== 1 ? 's' : ''}`,
                ephemeral: false
            });

        } catch (error) {
            console.error('Error banning member:', error);
            
            let errorMessage = 'An error occurred while trying to ban the user.';
            if (error.code === 10013) {
                errorMessage = 'Unknown user - they may have already left the server.';
            } else if (error.code === 50013) {
                errorMessage = 'Missing permissions to ban this user.';
            }

            await interaction.reply({
                content: errorMessage,
                ephemeral: true
            });
        }
    },
};
