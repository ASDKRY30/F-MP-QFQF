const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('poll')
        .setDescription('Crea una encuesta interactiva')
        .addStringOption(option =>
            option.setName('question')
                .setDescription('La pregunta de la encuesta')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('option1')
                .setDescription('Primera opción')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('option2')
                .setDescription('Segunda opción')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('option3')
                .setDescription('Tercera opción')
                .setRequired(false))
        .addStringOption(option =>
            option.setName('option4')
                .setDescription('Cuarta opción')
                .setRequired(false))
        .addIntegerOption(option =>
            option.setName('duration')
                .setDescription('Duración en minutos (máximo 1440 = 24 horas)')
                .setMinValue(1)
                .setMaxValue(1440)
                .setRequired(false)),

    async execute(interaction) {
        const question = interaction.options.getString('question');
        const option1 = interaction.options.getString('option1');
        const option2 = interaction.options.getString('option2');
        const option3 = interaction.options.getString('option3');
        const option4 = interaction.options.getString('option4');
        const duration = interaction.options.getInteger('duration') || 60; // Default 1 hour

        const options = [option1, option2, option3, option4].filter(opt => opt !== null);
        const emojis = ['1️⃣', '2️⃣', '3️⃣', '4️⃣'];
        
        const embed = new EmbedBuilder()
            .setColor(0x7289da)
            .setTitle('📊 Encuesta')
            .setDescription(`**${question}**\n\n${options.map((opt, i) => `${emojis[i]} ${opt}`).join('\n')}`)
            .addFields(
                { name: '⏱️ Duración', value: `${duration} minutos`, inline: true },
                { name: '👤 Creado por', value: interaction.user.tag, inline: true },
                { name: '📈 Votos', value: '0 votos totales', inline: true }
            )
            .setTimestamp()
            .setFooter({ text: 'Reacciona para votar' });

        const message = await interaction.reply({ embeds: [embed], fetchReply: true });

        // Add reactions
        for (let i = 0; i < options.length; i++) {
            await message.react(emojis[i]);
        }

        // Set timeout to end poll
        setTimeout(async () => {
            try {
                const updatedMessage = await message.fetch();
                const reactions = updatedMessage.reactions.cache;
                
                let results = [];
                let totalVotes = 0;
                
                for (let i = 0; i < options.length; i++) {
                    const reaction = reactions.get(emojis[i]);
                    const count = reaction ? reaction.count - 1 : 0; // -1 to exclude bot reaction
                    results.push({ option: options[i], votes: count });
                    totalVotes += count;
                }
                
                results.sort((a, b) => b.votes - a.votes);
                
                const resultEmbed = new EmbedBuilder()
                    .setColor(0x43b581)
                    .setTitle('📊 Resultados de la Encuesta')
                    .setDescription(`**${question}**\n\n${results.map((result, i) => 
                        `${i === 0 ? '🏆' : emojis[options.indexOf(result.option)]} **${result.option}**\n` +
                        `${result.votes} votos (${totalVotes > 0 ? Math.round((result.votes / totalVotes) * 100) : 0}%)`
                    ).join('\n\n')}`)
                    .addFields(
                        { name: '📈 Total de votos', value: totalVotes.toString(), inline: true },
                        { name: '🏆 Ganador', value: results[0].option, inline: true }
                    )
                    .setTimestamp()
                    .setFooter({ text: 'Encuesta finalizada' });

                await updatedMessage.edit({ embeds: [resultEmbed] });
            } catch (error) {
                console.error('Error updating poll results:', error);
            }
        }, duration * 60 * 1000);
    },
};