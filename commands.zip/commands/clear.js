const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { checkCEOPermission, denyCEOPermission } = require('../utils/ceo-check.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('clear')
        .setDescription('Borra mensajes del canal')
        .addIntegerOption(option =>
            option.setName('amount')
                .setDescription('Número de mensajes a borrar (1-100)')
                .setMinValue(1)
                .setMaxValue(100)
                .setRequired(true))
        .addUserOption(option =>
            option.setName('user')
                .setDescription('Borrar solo mensajes de este usuario')
                .setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

    async execute(interaction) {
        // Check CEO permission
        if (!checkCEOPermission(interaction)) {
            return await denyCEOPermission(interaction);
        }
        
        const amount = interaction.options.getInteger('amount');
        const targetUser = interaction.options.getUser('user');

        if (!interaction.guild.members.me.permissions.has(PermissionFlagsBits.ManageMessages)) {
            return await interaction.reply({
                content: '❌ No tengo permisos para borrar mensajes.',
                ephemeral: true
            });
        }

        await interaction.deferReply({ ephemeral: true });

        try {
            const fetched = await interaction.channel.messages.fetch({ limit: amount });
            
            let messagesToDelete = fetched;
            if (targetUser) {
                messagesToDelete = fetched.filter(msg => msg.author.id === targetUser.id);
            }

            const deleted = await interaction.channel.bulkDelete(messagesToDelete, true);

            const embed = new EmbedBuilder()
                .setColor(0x43b581)
                .setTitle('🧹 Mensajes Borrados')
                .setDescription(`Se borraron **${deleted.size}** mensajes exitosamente.`)
                .addFields(
                    { name: '📊 Solicitado', value: `${amount} mensajes`, inline: true },
                    { name: '🗑️ Borrados', value: `${deleted.size} mensajes`, inline: true },
                    { name: '👤 Usuario', value: targetUser ? `${targetUser.tag}` : 'Todos', inline: true }
                )
                .setTimestamp()
                .setFooter({ 
                    text: `Borrado por ${interaction.user.tag}`, 
                    iconURL: interaction.user.displayAvatarURL() 
                });

            await interaction.editReply({ embeds: [embed] });

        } catch (error) {
            await interaction.editReply({ 
                content: '❌ Hubo un error al borrar los mensajes. Pueden ser muy antiguos (más de 14 días).' 
            });
        }
    },
};