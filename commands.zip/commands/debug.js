const { SlashCommandBuilder, EmbedBuilder, AttachmentBuilder } = require('discord.js');
const { checkCEOPermission, denyCEOPermission } = require('../utils/ceo-check.js');
const fs = require('fs');
const path = require('path');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('debug')
        .setDescription('Herramientas de debug avanzadas para el bot (Solo CEO)')
        .addSubcommand(subcommand =>
            subcommand
                .setName('logs')
                .setDescription('Obtener logs recientes del bot'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('commands')
                .setDescription('Listar todos los comandos y su estado'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('events')
                .setDescription('Estado de los event listeners'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('guilds')
                .setDescription('Información detallada de servidores'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('cache')
                .setDescription('Estado de la caché de Discord.js'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('process')
                .setDescription('Información del proceso Node.js')),

    async execute(interaction) {
        // Check CEO permission
        if (!checkCEOPermission(interaction)) {
            return await denyCEOPermission(interaction);
        }

        await interaction.deferReply({ ephemeral: true });

        const subcommand = interaction.options.getSubcommand();
        const client = interaction.client;

        try {
            switch (subcommand) {
                case 'logs':
                    await this.handleLogs(interaction);
                    break;
                case 'commands':
                    await this.handleCommands(interaction, client);
                    break;
                case 'events':
                    await this.handleEvents(interaction, client);
                    break;
                case 'guilds':
                    await this.handleGuilds(interaction, client);
                    break;
                case 'cache':
                    await this.handleCache(interaction, client);
                    break;
                case 'process':
                    await this.handleProcess(interaction);
                    break;
                default:
                    await interaction.followUp({
                        content: '❌ Subcomando no reconocido.',
                        ephemeral: true
                    });
            }
        } catch (error) {
            const errorEmbed = new EmbedBuilder()
                .setTitle('❌ Error en Debug')
                .setDescription(`Error ejecutando debug ${subcommand}: ${error.message}`)
                .setColor(0xFF0000)
                .setFooter({ text: 'Developed by: Kry - Sistema Debug' })
                .setTimestamp();

            await interaction.followUp({
                embeds: [errorEmbed],
                ephemeral: true
            });
        }
    },

    async handleLogs(interaction) {
        // This would require a logging system that saves to files
        const debugEmbed = new EmbedBuilder()
            .setTitle('📋 Sistema de Logs')
            .setDescription('Sistema de logs avanzado - En desarrollo')
            .addFields([
                { name: '📝 Logs de Consola', value: 'Ver logs en la consola del sistema', inline: false },
                { name: '🚨 Errores Recientes', value: 'Sistema de tracking de errores activo', inline: false },
                { name: '📊 Métricas', value: 'Monitoreo de rendimiento habilitado', inline: false }
            ])
            .setColor(0x00FF00)
            .setFooter({ text: 'Developed by: Kry - Sistema de Logs' })
            .setTimestamp();

        await interaction.followUp({
            embeds: [debugEmbed],
            ephemeral: true
        });
    },

    async handleCommands(interaction, client) {
        const commands = Array.from(client.commands.values());
        
        const commandsInfo = commands.map(cmd => ({
            name: cmd.data.name,
            description: cmd.data.description,
            hasExecute: typeof cmd.execute === 'function',
            options: cmd.data.options ? cmd.data.options.length : 0
        }));

        const embed = new EmbedBuilder()
            .setTitle(`🔧 Debug: Comandos Cargados (${commands.length})`)
            .setDescription(`Total de comandos: **${commands.length}**`)
            .setColor(0x7289DA)
            .setFooter({ text: 'Developed by: Kry - Debug de Comandos' })
            .setTimestamp();

        // Create fields for commands (Discord has a field limit)
        const chunkedCommands = this.chunkArray(commandsInfo, 10);
        
        chunkedCommands.forEach((chunk, index) => {
            const fieldValue = chunk.map(cmd => 
                `\`/${cmd.name}\` - ${cmd.hasExecute ? '✅' : '❌'} (${cmd.options} opts)`
            ).join('\n');

            embed.addFields([{
                name: `Comandos ${index * 10 + 1}-${Math.min((index + 1) * 10, commandsInfo.length)}`,
                value: fieldValue || 'Sin comandos',
                inline: false
            }]);
        });

        await interaction.followUp({
            embeds: [embed],
            ephemeral: true
        });
    },

    async handleEvents(interaction, client) {
        const eventNames = client.eventNames();
        const listenerCounts = eventNames.map(eventName => ({
            name: eventName,
            count: client.listenerCount(eventName)
        }));

        const embed = new EmbedBuilder()
            .setTitle('🎯 Debug: Event Listeners')
            .setDescription(`Total de eventos: **${eventNames.length}**`)
            .addFields([
                {
                    name: 'Event Listeners Activos',
                    value: listenerCounts.map(event => 
                        `**${event.name}:** ${event.count} listeners`
                    ).join('\n') || 'Sin eventos',
                    inline: false
                },
                {
                    name: 'Estado de Conexión',
                    value: [
                        `**WebSocket Status:** ${client.ws.status}`,
                        `**Ready State:** ${client.isReady() ? 'Listo' : 'No listo'}`,
                        `**Ping:** ${client.ws.ping}ms`
                    ].join('\n'),
                    inline: true
                }
            ])
            .setColor(0xFF9900)
            .setFooter({ text: 'Developed by: Kry - Debug de Eventos' })
            .setTimestamp();

        await interaction.followUp({
            embeds: [embed],
            ephemeral: true
        });
    },

    async handleGuilds(interaction, client) {
        const guilds = Array.from(client.guilds.cache.values());
        
        const guildsInfo = guilds.map(guild => ({
            name: guild.name,
            id: guild.id,
            memberCount: guild.memberCount,
            channelCount: guild.channels.cache.size,
            roleCount: guild.roles.cache.size,
            owner: guild.ownerId
        }));

        const embed = new EmbedBuilder()
            .setTitle(`🏠 Debug: Servidores (${guilds.length})`)
            .setColor(0x00FFFF)
            .setFooter({ text: 'Developed by: Kry - Debug de Servidores' })
            .setTimestamp();

        if (guildsInfo.length > 0) {
            const guildsList = guildsInfo.map(guild => 
                `**${guild.name}**\n` +
                `ID: \`${guild.id}\`\n` +
                `Miembros: ${guild.memberCount} | Canales: ${guild.channelCount} | Roles: ${guild.roleCount}`
            ).join('\n\n');

            // Split into chunks if too long
            if (guildsList.length > 4000) {
                embed.setDescription('Información de servidores (truncada por límite)');
                embed.addFields([{
                    name: 'Servidores',
                    value: guildsList.substring(0, 1000) + '...',
                    inline: false
                }]);
            } else {
                embed.setDescription(guildsList);
            }
        } else {
            embed.setDescription('No hay servidores conectados.');
        }

        await interaction.followUp({
            embeds: [embed],
            ephemeral: true
        });
    },

    async handleCache(interaction, client) {
        const cacheInfo = {
            guilds: client.guilds.cache.size,
            users: client.users.cache.size,
            channels: client.channels.cache.size,
            roles: client.guilds.cache.reduce((acc, guild) => acc + guild.roles.cache.size, 0),
            members: client.guilds.cache.reduce((acc, guild) => acc + guild.members.cache.size, 0),
            messages: client.channels.cache.reduce((acc, channel) => {
                return acc + (channel.messages?.cache.size || 0);
            }, 0)
        };

        const embed = new EmbedBuilder()
            .setTitle('💾 Debug: Estado de la Caché')
            .addFields([
                { name: '🏠 Servidores', value: cacheInfo.guilds.toString(), inline: true },
                { name: '👥 Usuarios', value: cacheInfo.users.toString(), inline: true },
                { name: '📺 Canales', value: cacheInfo.channels.toString(), inline: true },
                { name: '🎭 Roles', value: cacheInfo.roles.toString(), inline: true },
                { name: '👤 Miembros', value: cacheInfo.members.toString(), inline: true },
                { name: '💬 Mensajes', value: cacheInfo.messages.toString(), inline: true }
            ])
            .setColor(0x9966CC)
            .setFooter({ text: 'Developed by: Kry - Debug de Caché' })
            .setTimestamp();

        await interaction.followUp({
            embeds: [embed],
            ephemeral: true
        });
    },

    async handleProcess(interaction) {
        const processInfo = {
            version: process.version,
            platform: process.platform,
            arch: process.arch,
            pid: process.pid,
            uptime: process.uptime(),
            memoryUsage: process.memoryUsage(),
            cpuUsage: process.cpuUsage()
        };

        const embed = new EmbedBuilder()
            .setTitle('🖥️ Debug: Proceso Node.js')
            .addFields([
                {
                    name: 'Información Básica',
                    value: [
                        `**Versión:** ${processInfo.version}`,
                        `**Plataforma:** ${processInfo.platform}`,
                        `**Arquitectura:** ${processInfo.arch}`,
                        `**PID:** ${processInfo.pid}`
                    ].join('\n'),
                    inline: true
                },
                {
                    name: 'Memoria (MB)',
                    value: [
                        `**RSS:** ${Math.round(processInfo.memoryUsage.rss / 1024 / 1024)}`,
                        `**Heap Used:** ${Math.round(processInfo.memoryUsage.heapUsed / 1024 / 1024)}`,
                        `**Heap Total:** ${Math.round(processInfo.memoryUsage.heapTotal / 1024 / 1024)}`,
                        `**External:** ${Math.round(processInfo.memoryUsage.external / 1024 / 1024)}`
                    ].join('\n'),
                    inline: true
                },
                {
                    name: 'CPU Usage',
                    value: [
                        `**User:** ${processInfo.cpuUsage.user}μs`,
                        `**System:** ${processInfo.cpuUsage.system}μs`,
                        `**Uptime:** ${Math.floor(processInfo.uptime / 3600)}h ${Math.floor((processInfo.uptime % 3600) / 60)}m`
                    ].join('\n'),
                    inline: true
                }
            ])
            .setColor(0xFF6600)
            .setFooter({ text: 'Developed by: Kry - Debug del Proceso' })
            .setTimestamp();

        await interaction.followUp({
            embeds: [embed],
            ephemeral: true
        });
    },

    chunkArray(array, size) {
        const chunks = [];
        for (let i = 0; i < array.length; i += size) {
            chunks.push(array.slice(i, i + size));
        }
        return chunks;
    }
};