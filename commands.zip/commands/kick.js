const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { hasPermission, isHigherRole } = require('../utils/permissions.js');
const { checkCEOPermission, denyCEOPermission } = require('../utils/ceo-check.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('kick')
        .setDescription('Kick a member from the server')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('The user to kick')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('reason')
                .setDescription('Reason for the kick')
                .setRequired(false))
        .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers),
    
    async execute(interaction) {
        // Check CEO permission
        if (!checkCEOPermission(interaction)) {
            return await denyCEOPermission(interaction);
        }
        
        const targetUser = interaction.options.getUser('user');
        const reason = interaction.options.getString('reason') || 'No reason provided';
        
        // Check if command is used in a guild
        if (!interaction.guild) {
            return await interaction.reply({
                content: 'This command can only be used in a server!',
                ephemeral: true
            });
        }

        // Check bot permissions
        if (!hasPermission(interaction.guild.members.me, PermissionFlagsBits.KickMembers)) {
            return await interaction.reply({
                content: 'I don\'t have permission to kick members!',
                ephemeral: true
            });
        }

        // Get target member
        const targetMember = await interaction.guild.members.fetch(targetUser.id).catch(() => null);
        
        if (!targetMember) {
            return await interaction.reply({
                content: 'User not found in this server!',
                ephemeral: true
            });
        }

        // Prevent self-kick
        if (targetUser.id === interaction.user.id) {
            return await interaction.reply({
                content: 'You cannot kick yourself!',
                ephemeral: true
            });
        }

        // Prevent kicking the bot owner or higher roles
        if (targetUser.id === interaction.guild.ownerId) {
            return await interaction.reply({
                content: 'You cannot kick the server owner!',
                ephemeral: true
            });
        }

        // Check if target is kickable
        if (!targetMember.kickable) {
            return await interaction.reply({
                content: 'I cannot kick this user! They may have higher permissions than me.',
                ephemeral: true
            });
        }

        // Check role hierarchy
        const executorMember = interaction.member;
        if (!isHigherRole(executorMember, targetMember)) {
            return await interaction.reply({
                content: 'You cannot kick someone with an equal or higher role than yours!',
                ephemeral: true
            });
        }

        try {
            // Send DM to user before kicking (optional)
            try {
                await targetUser.send(
                    `You have been kicked from **${interaction.guild.name}**\n` +
                    `**Reason:** ${reason}\n` +
                    `**Kicked by:** ${interaction.user.tag}`
                );
            } catch (error) {
                // Ignore DM errors (user might have DMs disabled)
            }

            // Kick the member
            await targetMember.kick(reason);

            await interaction.reply({
                content: `✅ Successfully kicked **${targetUser.tag}**\n**Reason:** ${reason}`,
                ephemeral: false
            });

        } catch (error) {
            console.error('Error kicking member:', error);
            await interaction.reply({
                content: 'An error occurred while trying to kick the user.',
                ephemeral: true
            });
        }
    },
};
