const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { checkCEOPermission, denyCEOPermission } = require('../utils/ceo-check.js');
const logger = require('../utils/logger.js');

// Anti-raid configuration storage
const antiRaidConfig = new Map();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('antiraid')
        .setDescription('Configura el sistema anti-raid del servidor')
        .addSubcommand(subcommand =>
            subcommand
                .setName('enable')
                .setDescription('Activa el sistema anti-raid')
                .addIntegerOption(option =>
                    option.setName('max_joins')
                        .setDescription('Máximo de usuarios que pueden unirse en el tiempo límite')
                        .setMinValue(1)
                        .setMaxValue(20)
                        .setRequired(true))
                .addIntegerOption(option =>
                    option.setName('time_window')
                        .setDescription('Ventana de tiempo en segundos')
                        .setMinValue(10)
                        .setMaxValue(300)
                        .setRequired(true)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('disable')
                .setDescription('Desactiva el sistema anti-raid'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('status')
                .setDescription('Muestra el estado del sistema anti-raid'))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

    async execute(interaction) {
        // Check CEO permission
        if (!checkCEOPermission(interaction)) {
            return await denyCEOPermission(interaction);
        }
        
        const subcommand = interaction.options.getSubcommand();
        const guildId = interaction.guild.id;

        if (subcommand === 'enable') {
            const maxJoins = interaction.options.getInteger('max_joins');
            const timeWindow = interaction.options.getInteger('time_window');

            antiRaidConfig.set(guildId, {
                enabled: true,
                maxJoins,
                timeWindow,
                recentJoins: []
            });

            const embed = new EmbedBuilder()
                .setColor(0x43b581)
                .setTitle('🛡️ Sistema Anti-Raid Activado')
                .setDescription('El sistema de protección anti-raid ha sido configurado exitosamente.')
                .addFields(
                    { name: '👥 Máximo de uniones', value: `${maxJoins} usuarios`, inline: true },
                    { name: '⏱️ Ventana de tiempo', value: `${timeWindow} segundos`, inline: true },
                    { name: '🔒 Acción', value: 'Kick automático cuando se supere el límite', inline: false }
                )
                .setTimestamp()
                .setFooter({ text: 'Sistema Anti-Raid', iconURL: interaction.client.user.displayAvatarURL() });

            await interaction.reply({ embeds: [embed] });
            logger.info(`Anti-raid enabled for guild ${guildId} with ${maxJoins} joins in ${timeWindow}s`);

        } else if (subcommand === 'disable') {
            antiRaidConfig.delete(guildId);

            const embed = new EmbedBuilder()
                .setColor(0xf04747)
                .setTitle('🛡️ Sistema Anti-Raid Desactivado')
                .setDescription('El sistema de protección anti-raid ha sido desactivado.')
                .setTimestamp()
                .setFooter({ text: 'Sistema Anti-Raid', iconURL: interaction.client.user.displayAvatarURL() });

            await interaction.reply({ embeds: [embed] });
            logger.info(`Anti-raid disabled for guild ${guildId}`);

        } else if (subcommand === 'status') {
            const config = antiRaidConfig.get(guildId);

            const embed = new EmbedBuilder()
                .setColor(config?.enabled ? 0x43b581 : 0xf04747)
                .setTitle('🛡️ Estado del Sistema Anti-Raid')
                .setTimestamp()
                .setFooter({ text: 'Sistema Anti-Raid', iconURL: interaction.client.user.displayAvatarURL() });

            if (config?.enabled) {
                embed.setDescription('✅ Sistema activo y funcionando')
                    .addFields(
                        { name: '👥 Máximo de uniones', value: `${config.maxJoins} usuarios`, inline: true },
                        { name: '⏱️ Ventana de tiempo', value: `${config.timeWindow} segundos`, inline: true },
                        { name: '📊 Uniones recientes', value: `${config.recentJoins.length} usuarios`, inline: true }
                    );
            } else {
                embed.setDescription('❌ Sistema desactivado');
            }

            await interaction.reply({ embeds: [embed] });
        }
    },

    // Export configuration for use in events
    getConfig: (guildId) => antiRaidConfig.get(guildId),
    updateRecentJoins: (guildId, userId) => {
        const config = antiRaidConfig.get(guildId);
        if (!config) return false;

        const now = Date.now();
        config.recentJoins = config.recentJoins.filter(join => now - join.time < config.timeWindow * 1000);
        config.recentJoins.push({ userId, time: now });

        return config.recentJoins.length > config.maxJoins;
    }
};