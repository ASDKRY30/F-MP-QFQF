const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { checkCEOPermission, denyCEOPermission } = require('../utils/ceo-check.js');
const performanceMonitor = require('../utils/performance-monitor.js');
const { createInfoEmbed } = require('../utils/interaction-handler.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('botstats')
        .setDescription('Estadísticas avanzadas del bot y análisis de rendimiento (Solo CEO)'),

    async execute(interaction) {
        // Check CEO permission
        if (!checkCEOPermission(interaction)) {
            return await denyCEOPermission(interaction);
        }

        await interaction.deferReply({ ephemeral: true });

        try {
            const client = interaction.client;
            const stats = performanceMonitor.getStats();
            const memoryStats = performanceMonitor.getMemoryStats();
            const healthCheck = performanceMonitor.healthCheck();

            // Get status emoji and color based on health
            let statusEmoji = '🟢';
            let statusColor = 0x00FF00;
            
            if (healthCheck.status === 'warning') {
                statusEmoji = '🟡';
                statusColor = 0xFFFF00;
            } else if (healthCheck.status === 'critical') {
                statusEmoji = '🔴';
                statusColor = 0xFF0000;
            }

            // Main statistics embed
            const mainEmbed = new EmbedBuilder()
                .setTitle('📊 Estadísticas Avanzadas del Bot - 30K-BOT')
                .setDescription(`${statusEmoji} **Estado del Sistema:** ${healthCheck.status.toUpperCase()}`)
                .addFields([
                    { name: '🏠 Información del Bot', value: [
                        `**Nombre:** ${client.user.tag}`,
                        `**ID:** ${client.user.id}`,
                        `**Versión:** Discord.js v14`,
                        `**Creado:** <t:${Math.floor(client.user.createdTimestamp / 1000)}:R>`
                    ].join('\n'), inline: false },
                    
                    { name: '🌐 Estadísticas de Servidor', value: [
                        `**Servidores:** ${client.guilds.cache.size}`,
                        `**Usuarios:** ${client.guilds.cache.reduce((acc, guild) => acc + guild.memberCount, 0)}`,
                        `**Canales:** ${client.channels.cache.size}`,
                        `**Comandos Cargados:** ${client.commands.size}`
                    ].join('\n'), inline: true },
                    
                    { name: '⚡ Rendimiento', value: [
                        `**Comandos Ejecutados:** ${stats.totalCommands}`,
                        `**Tasa de Éxito:** ${stats.successRate}%`,
                        `**Tasa de Error:** ${stats.errorRate}%`,
                        `**Tiempo Promedio:** ${stats.averageResponseTime}ms`
                    ].join('\n'), inline: true },
                    
                    { name: '💾 Memoria', value: [
                        `**Heap Usado:** ${memoryStats.heapUsed}MB`,
                        `**Heap Total:** ${memoryStats.heapTotal}MB`,
                        `**RSS:** ${memoryStats.rss}MB`,
                        `**Externo:** ${memoryStats.external}MB`
                    ].join('\n'), inline: true },
                    
                    { name: '⏰ Tiempo de Actividad', value: [
                        `**Uptime:** ${stats.uptime}`,
                        `**Proceso:** ${Math.floor(process.uptime() / 3600)}h ${Math.floor((process.uptime() % 3600) / 60)}m`,
                        `**Ping API:** ${Math.round(client.ws.ping)}ms`,
                        `**Inicio:** <t:${Math.floor((Date.now() - stats.uptimeMs) / 1000)}:R>`
                    ].join('\n'), inline: true },
                    
                    { name: '🔒 Seguridad CEO', value: [
                        `**Sistema Activo:** ✅ Sí`,
                        `**Restricciones:** ✅ Aplicadas`,
                        `**Monitoreo:** ✅ Activo`,
                        `**Logs:** ✅ Registrando`
                    ].join('\n'), inline: true }
                ])
                .setColor(statusColor)
                .setTimestamp()
                .setFooter({ text: 'Developed by: Kry - Sistema de Estadísticas Avanzadas' })
                .setThumbnail(client.user.displayAvatarURL());

            // Health issues if any
            if (healthCheck.issues.length > 0) {
                mainEmbed.addFields([
                    { name: '⚠️ Problemas Detectados', value: healthCheck.issues.join('\n'), inline: false }
                ]);
            }

            // Top commands embed
            const commandsEmbed = new EmbedBuilder()
                .setTitle('📈 Top Comandos Más Usados')
                .setColor(0x7289DA)
                .setFooter({ text: 'Developed by: Kry - Análisis de Comandos' });

            if (stats.commandBreakdown.length > 0) {
                const topCommands = stats.commandBreakdown.slice(0, 10);
                commandsEmbed.setDescription(
                    topCommands.map((cmd, index) => 
                        `**${index + 1}.** \`/${cmd.command}\` - ${cmd.executions} usos (${cmd.averageTime}ms avg, ${cmd.errorRate}% errores)`
                    ).join('\n')
                );
            } else {
                commandsEmbed.setDescription('No hay datos de comandos disponibles aún.');
            }

            // System info embed
            const systemEmbed = new EmbedBuilder()
                .setTitle('🖥️ Información del Sistema')
                .addFields([
                    { name: '🔧 Runtime', value: [
                        `**Node.js:** ${process.version}`,
                        `**Plataforma:** ${process.platform}`,
                        `**Arquitectura:** ${process.arch}`,
                        `**PID:** ${process.pid}`
                    ].join('\n'), inline: true },
                    
                    { name: '📁 Directorios', value: [
                        `**Comandos:** ${require('fs').readdirSync('./commands').length} archivos`,
                        `**Eventos:** ${require('fs').readdirSync('./events').length} archivos`,
                        `**Utilidades:** ${require('fs').readdirSync('./utils').length} archivos`,
                        `**Datos:** ${require('fs').existsSync('./data') ? 'Directorio creado' : 'No existe'}`
                    ].join('\n'), inline: true },
                    
                    { name: '🌐 Conexión', value: [
                        `**WebSocket:** ${client.ws.status === 0 ? '🟢 Conectado' : '🔴 Desconectado'}`,
                        `**Heartbeat:** ${client.ws.ping}ms`,
                        `**Ready:** ${client.isReady() ? '✅' : '❌'}`,
                        `**Uptime:** ${(Date.now() - client.readyTimestamp) / 1000 / 60 | 0}min`
                    ].join('\n'), inline: true }
                ])
                .setColor(0x00FFFF)
                .setTimestamp()
                .setFooter({ text: 'Developed by: Kry - Info del Sistema' });

            // Create action buttons
            const buttons = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId('refresh_stats')
                        .setLabel('🔄 Actualizar')
                        .setStyle(ButtonStyle.Primary),
                    new ButtonBuilder()
                        .setCustomId('reset_stats')
                        .setLabel('🗑️ Reset Stats')
                        .setStyle(ButtonStyle.Danger),
                    new ButtonBuilder()
                        .setCustomId('export_stats')
                        .setLabel('📊 Exportar')
                        .setStyle(ButtonStyle.Secondary)
                );

            await interaction.followUp({
                embeds: [mainEmbed, commandsEmbed, systemEmbed],
                components: [buttons],
                ephemeral: true
            });

        } catch (error) {
            const errorEmbed = createErrorEmbed(
                'Error en Estadísticas',
                'No se pudieron cargar las estadísticas del bot.',
                [{ name: 'Error', value: error.message, inline: true }]
            );

            await interaction.followUp({
                embeds: [errorEmbed],
                ephemeral: true
            });
        }
    },
};