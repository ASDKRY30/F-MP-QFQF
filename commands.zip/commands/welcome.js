const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { checkCEOPermission, denyCEOPermission } = require('../utils/ceo-check.js');
const fs = require('fs');
const path = require('path');

// Welcome configuration storage
const welcomeConfig = new Map();
const configPath = path.join(__dirname, '../data/welcome.json');

// Load existing configuration
function loadWelcomeConfig() {
    try {
        if (fs.existsSync(configPath)) {
            const data = fs.readFileSync(configPath, 'utf8');
            const configs = JSON.parse(data);
            for (const [guildId, config] of Object.entries(configs)) {
                welcomeConfig.set(guildId, config);
            }
        }
    } catch (error) {
        console.error('Error loading welcome config:', error);
    }
}

// Save configuration
function saveWelcomeConfig() {
    try {
        const dataDir = path.dirname(configPath);
        if (!fs.existsSync(dataDir)) {
            fs.mkdirSync(dataDir, { recursive: true });
        }
        const configs = Object.fromEntries(welcomeConfig);
        fs.writeFileSync(configPath, JSON.stringify(configs, null, 2));
    } catch (error) {
        console.error('Error saving welcome config:', error);
    }
}

loadWelcomeConfig();

module.exports = {
    data: new SlashCommandBuilder()
        .setName('welcome')
        .setDescription('Configura mensajes de bienvenida')
        .addSubcommand(subcommand =>
            subcommand
                .setName('set')
                .setDescription('Configura el mensaje de bienvenida')
                .addChannelOption(option =>
                    option.setName('channel')
                        .setDescription('Canal donde enviar mensajes de bienvenida')
                        .setRequired(true))
                .addStringOption(option =>
                    option.setName('message')
                        .setDescription('Mensaje personalizado (usa {user} para mencionar y {server} para el nombre del servidor)')
                        .setRequired(false)))
        .addSubcommand(subcommand =>
            subcommand
                .setName('disable')
                .setDescription('Desactiva los mensajes de bienvenida'))
        .addSubcommand(subcommand =>
            subcommand
                .setName('test')
                .setDescription('Prueba el mensaje de bienvenida'))
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

    async execute(interaction) {
        // Check CEO permission
        if (!checkCEOPermission(interaction)) {
            return await denyCEOPermission(interaction);
        }
        
        const subcommand = interaction.options.getSubcommand();
        const guildId = interaction.guild.id;

        if (subcommand === 'set') {
            const channel = interaction.options.getChannel('channel');
            const customMessage = interaction.options.getString('message');

            const config = {
                channelId: channel.id,
                message: customMessage || '🎉 ¡Bienvenido/a {user} a **{server}**! ¡Esperamos que disfrutes tu estancia! 🎊',
                enabled: true
            };

            welcomeConfig.set(guildId, config);
            saveWelcomeConfig();

            const embed = new EmbedBuilder()
                .setColor(0x43b581)
                .setTitle('👋 Sistema de Bienvenida Configurado')
                .setDescription('El sistema de mensajes de bienvenida ha sido configurado exitosamente.')
                .addFields(
                    { name: '📺 Canal', value: `${channel}`, inline: true },
                    { name: '💬 Mensaje', value: config.message.substring(0, 100) + (config.message.length > 100 ? '...' : ''), inline: false }
                )
                .setTimestamp()
                .setFooter({ text: 'Sistema de Bienvenida', iconURL: interaction.client.user.displayAvatarURL() });

            await interaction.reply({ embeds: [embed] });

        } else if (subcommand === 'disable') {
            welcomeConfig.delete(guildId);
            saveWelcomeConfig();

            const embed = new EmbedBuilder()
                .setColor(0xf04747)
                .setTitle('👋 Sistema de Bienvenida Desactivado')
                .setDescription('Los mensajes de bienvenida han sido desactivados.')
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });

        } else if (subcommand === 'test') {
            const config = welcomeConfig.get(guildId);

            if (!config) {
                return await interaction.reply({
                    content: '❌ No hay configuración de bienvenida. Usa `/welcome set` primero.',
                    ephemeral: true
                });
            }

            const channel = interaction.guild.channels.cache.get(config.channelId);
            if (!channel) {
                return await interaction.reply({
                    content: '❌ El canal configurado ya no existe.',
                    ephemeral: true
                });
            }

            // Send test welcome message
            this.sendWelcomeMessage(interaction.guild, interaction.user, channel, config.message);

            await interaction.reply({
                content: `✅ Mensaje de prueba enviado en ${channel}`,
                ephemeral: true
            });
        }
    },

    // Function to send welcome message (used by guildMemberAdd event)
    sendWelcomeMessage: async (guild, member, channel, customMessage) => {
        const message = customMessage
            .replace(/\{user\}/g, `<@${member.id}>`)
            .replace(/\{server\}/g, guild.name);

        const welcomeEmbed = new EmbedBuilder()
            .setColor(0x43b581)
            .setTitle('🎉 ¡Nuevo Miembro!')
            .setDescription(message)
            .setThumbnail(member.displayAvatarURL({ dynamic: true, size: 128 }))
            .addFields(
                { name: '👤 Usuario', value: member.tag, inline: true },
                { name: '🆔 ID', value: member.id, inline: true },
                { name: '📅 Cuenta creada', value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>`, inline: true },
                { name: '👥 Miembro #', value: `${guild.memberCount}`, inline: true }
            )
            .setTimestamp()
            .setFooter({ 
                text: `${guild.name} • Sistema de Bienvenida`, 
                iconURL: guild.iconURL({ dynamic: true }) 
            });

        try {
            await channel.send({ 
                content: `<@${member.id}>`,
                embeds: [welcomeEmbed] 
            });
        } catch (error) {
            console.error('Error sending welcome message:', error);
        }
    },

    // Export configuration getter
    getConfig: (guildId) => welcomeConfig.get(guildId)
};